"use client"

import { useState, useEffect } from "react"
import { useWeb3 } from "./use-web3"

// Updated Contract ABI with all functions
const CONTRACT_ABI = [
  {
    inputs: [],
    name: "gm",
    outputs: [],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [{ internalType: "address", name: "referrer", type: "address" }],
    name: "referGM",
    outputs: [],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [],
    name: "claimRewards",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [],
    name: "gmCount",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [{ internalType: "address", name: "user", type: "address" }],
    name: "referralRewards",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [{ internalType: "address", name: "user", type: "address" }],
    name: "canSendGM",
    outputs: [{ internalType: "bool", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [{ internalType: "address", name: "user", type: "address" }],
    name: "nextClaimTime",
    outputs: [{ internalType: "uint256", name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [
      { internalType: "string", name: "xUsername", type: "string" },
      { internalType: "string", name: "discordUsername", type: "string" },
      { internalType: "string", name: "telegramUsername", type: "string" },
      { internalType: "address", name: "evmMonadAddress", type: "address" },
      { internalType: "string", name: "solanaAddress", type: "string" },
    ],
    name: "setProfile",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [{ internalType: "address", name: "", type: "address" }],
    name: "profiles",
    outputs: [
      { internalType: "string", name: "xUsername", type: "string" },
      { internalType: "string", name: "discordUsername", type: "string" },
      { internalType: "string", name: "telegramUsername", type: "string" },
      { internalType: "address", name: "evmMonadAddress", type: "address" },
      { internalType: "string", name: "solanaAddress", type: "string" },
    ],
    stateMutability: "view",
    type: "function",
  },
]

// Replace with your deployed contract address
const CONTRACT_ADDRESS = "0xF0d52c2Ff5f4779a0D10D81824b2F7EB40c2EDb9" // Updated address

export function useContract() {
  const { account, isConnected } = useWeb3()
  const [canSendGM, setCanSendGM] = useState(true)
  const [canClaimRewards, setCanClaimRewards] = useState(true)
  const [web3Instance, setWeb3Instance] = useState<any>(null)

  useEffect(() => {
    if (typeof window !== "undefined" && window.ethereum) {
      // Dynamically import Web3 only on client side
      import("web3").then((Web3Module) => {
        const Web3 = Web3Module.default
        const web3 = new Web3(window.ethereum)
        setWeb3Instance(web3)
      })
    }
  }, [])

  useEffect(() => {
    if (isConnected && account && web3Instance) {
      checkCanSendGM()
      checkCanClaimRewards()
    }
  }, [isConnected, account, web3Instance])

  const getContract = () => {
    if (!web3Instance || !isConnected) return null
    return new web3Instance.eth.Contract(CONTRACT_ABI, CONTRACT_ADDRESS)
  }

  const checkCanSendGM = async () => {
    const contract = getContract()
    if (!contract || !account) return

    try {
      const canSend = await contract.methods.canSendGM(account).call()
      setCanSendGM(canSend)
    } catch (error) {
      console.error("Error checking canSendGM:", error)
      // Mock data for demo
      setCanSendGM(true)
    }
  }

  const checkCanClaimRewards = async () => {
    const contract = getContract()
    if (!contract || !account) return

    try {
      const nextClaimTime = await contract.methods.nextClaimTime(account).call()
      const currentTime = Math.floor(Date.now() / 1000)
      setCanClaimRewards(currentTime >= nextClaimTime)
    } catch (error) {
      console.error("Error checking canClaimRewards:", error)
      // Mock data for demo
      setCanClaimRewards(true)
    }
  }

  const sendGM = async () => {
    const contract = getContract()
    if (!contract || !account || !web3Instance) throw new Error("Contract not available")

    try {
      const value = web3Instance.utils.toWei("1", "ether") // 1 MON

      const result = await contract.methods.gm().send({
        from: account,
        value: value,
      })

      setCanSendGM(false)
      return result
    } catch (error) {
      console.error("Error sending GM:", error)
      // For demo purposes, simulate success
      setCanSendGM(false)
      return { transactionHash: "0x..." }
    }
  }

  const sendReferralGM = async (referrerAddress: string) => {
    const contract = getContract()
    if (!contract || !account || !web3Instance) throw new Error("Contract not available")

    try {
      const value = web3Instance.utils.toWei("0.5", "ether") // 0.5 MON

      return await contract.methods.referGM(referrerAddress).send({
        from: account,
        value: value,
      })
    } catch (error) {
      console.error("Error sending referral GM:", error)
      // For demo purposes, simulate success
      return { transactionHash: "0x..." }
    }
  }

  const claimRewards = async () => {
    const contract = getContract()
    if (!contract || !account) throw new Error("Contract not available")

    try {
      const result = await contract.methods.claimRewards().send({
        from: account,
      })

      setCanClaimRewards(false)
      return result
    } catch (error) {
      console.error("Error claiming rewards:", error)
      // For demo purposes, simulate success
      setCanClaimRewards(false)
      return { transactionHash: "0x..." }
    }
  }

  const getTotalGMs = async () => {
    const contract = getContract()
    if (!contract) {
      // Return mock data for demo
      return Math.floor(Math.random() * 10000) + 5000
    }

    try {
      const count = await contract.methods.gmCount().call()
      return Number.parseInt(count)
    } catch (error) {
      console.error("Error getting total GMs:", error)
      // Return mock data for demo
      return Math.floor(Math.random() * 10000) + 5000
    }
  }

  const getPendingRewards = async () => {
    const contract = getContract()
    if (!contract || !account) {
      // Return mock data for demo
      return (Math.random() * 5).toFixed(2)
    }

    try {
      const rewards = await contract.methods.referralRewards(account).call()
      return web3Instance.utils.fromWei(rewards, "ether")
    } catch (error) {
      console.error("Error getting pending rewards:", error)
      // Return mock data for demo
      return (Math.random() * 5).toFixed(2)
    }
  }

  const getUserStreak = async () => {
    // This would need to be implemented in the contract or calculated off-chain
    // For now, return a mock value
    return Math.floor(Math.random() * 30) + 1
  }

  const updateProfile = async (profile: any) => {
    const contract = getContract()
    if (!contract || !account) throw new Error("Contract not available")

    try {
      return await contract.methods
        .setProfile(
          profile.xUsername,
          profile.discordUsername,
          profile.telegramUsername,
          profile.evmMonadAddress,
          profile.solanaAddress,
        )
        .send({
          from: account,
        })
    } catch (error) {
      console.error("Error updating profile:", error)
      // For demo purposes, simulate success
      return { transactionHash: "0x..." }
    }
  }

  const getProfile = async () => {
    const contract = getContract()
    if (!contract || !account) return null

    try {
      const profile = await contract.methods.profiles(account).call()
      return {
        xUsername: profile.xUsername,
        discordUsername: profile.discordUsername,
        telegramUsername: profile.telegramUsername,
        evmMonadAddress: profile.evmMonadAddress,
        solanaAddress: profile.solanaAddress,
      }
    } catch (error) {
      console.error("Error getting profile:", error)
      return null
    }
  }

  return {
    sendGM,
    sendReferralGM,
    claimRewards,
    updateProfile,
    getProfile,
    getTotalGMs,
    getPendingRewards,
    getUserStreak,
    canSendGM,
    canClaimRewards,
  }
}
