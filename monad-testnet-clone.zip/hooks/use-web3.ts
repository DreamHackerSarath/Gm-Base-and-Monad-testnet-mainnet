"use client"

import { useState, useEffect } from "react"

declare global {
  interface Window {
    ethereum?: any
  }
}

export function useWeb3() {
  const [account, setAccount] = useState<string | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [balance, setBalance] = useState<string | null>(null)

  useEffect(() => {
    checkConnection()

    if (window.ethereum) {
      window.ethereum.on("accountsChanged", handleAccountsChanged)
      window.ethereum.on("chainChanged", () => window.location.reload())
    }

    return () => {
      if (window.ethereum) {
        window.ethereum.removeListener("accountsChanged", handleAccountsChanged)
      }
    }
  }, [])

  const checkConnection = async () => {
    if (window.ethereum) {
      try {
        const accounts = await window.ethereum.request({ method: "eth_accounts" })
        if (accounts.length > 0) {
          setAccount(accounts[0])
          setIsConnected(true)
          await switchToMonadTestnet()
          await fetchBalance(accounts[0])
        }
      } catch (error) {
        console.error("Error checking connection:", error)
      }
    }
  }

  const handleAccountsChanged = (accounts: string[]) => {
    if (accounts.length > 0) {
      setAccount(accounts[0])
      setIsConnected(true)
      fetchBalance(accounts[0])
    } else {
      setAccount(null)
      setIsConnected(false)
      setBalance(null)
    }
  }

  const switchToMonadTestnet = async () => {
    if (!window.ethereum) return

    try {
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: "0x279f" }], // 10143 in hex for Monad testnet
      })
    } catch (switchError: any) {
      if (switchError.code === 4902) {
        try {
          await window.ethereum.request({
            method: "wallet_addEthereumChain",
            params: [
              {
                chainId: "0x279f", // Updated to correct Chain ID
                chainName: "Monad Testnet",
                nativeCurrency: {
                  name: "MON",
                  symbol: "MON",
                  decimals: 18,
                },
                rpcUrls: ["https://testnet-rpc.monad.xyz"],
                blockExplorerUrls: ["https://testnet-explorer.monad.xyz"],
              },
            ],
          })
        } catch (addError) {
          console.error("Error adding Monad testnet:", addError)
        }
      }
    }
  }

  const connect = async () => {
    if (!window.ethereum) {
      alert("Please install MetaMask!")
      return
    }

    try {
      const accounts = await window.ethereum.request({
        method: "eth_requestAccounts",
      })

      if (accounts.length > 0) {
        setAccount(accounts[0])
        setIsConnected(true)
        await switchToMonadTestnet()
        await fetchBalance(accounts[0])
      }
    } catch (error) {
      console.error("Error connecting wallet:", error)
    }
  }

  const disconnect = () => {
    setAccount(null)
    setIsConnected(false)
    setBalance(null)
  }

  const fetchBalance = async (account: string) => {
    if (!window.ethereum) return

    try {
      const balance = await window.ethereum.request({
        method: "eth_getBalance",
        params: [account, "latest"],
      })

      // Convert hex balance to decimal and then to ether
      const balanceInWei = Number.parseInt(balance, 16)
      const balanceInEther = (balanceInWei / Math.pow(10, 18)).toFixed(4)
      setBalance(balanceInEther)
      console.log("Account balance:", balanceInEther, "MON")
    } catch (error) {
      console.error("Error fetching balance:", error)
    }
  }

  return {
    account,
    isConnected,
    balance,
    connect,
    disconnect,
  }
}
