"use client"

import { useState, useEffect } from "react"

interface EcosystemData {
  totalProjects: number
  totalTVL: string
  activeUsers: number
  dailyTransactions: number
}

export function useMonadEcosystem() {
  const [ecosystemData, setEcosystemData] = useState<EcosystemData>({
    totalProjects: 0,
    totalTVL: "0",
    activeUsers: 0,
    dailyTransactions: 0,
  })

  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate fetching ecosystem data
    const fetchEcosystemData = async () => {
      setIsLoading(true)

      // In production, this would fetch from Monad ecosystem APIs
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setEcosystemData({
        totalProjects: 12,
        totalTVL: "50.2M",
        activeUsers: 125000,
        dailyTransactions: 2500000,
      })

      setIsLoading(false)
    }

    fetchEcosystemData()
  }, [])

  const refreshData = () => {
    setEcosystemData((prev) => ({
      ...prev,
      activeUsers: prev.activeUsers + Math.floor(Math.random() * 100),
      dailyTransactions: prev.dailyTransactions + Math.floor(Math.random() * 10000),
    }))
  }

  return {
    ecosystemData,
    isLoading,
    refreshData,
  }
}
