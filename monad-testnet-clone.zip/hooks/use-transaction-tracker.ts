"use client"

import { useState, useCallback } from "react"

interface Transaction {
  hash: string
  type: "gm" | "referral" | "claim" | "profile"
  status: "pending" | "confirmed" | "failed"
  timestamp: number
  blockNumber?: number
  gasUsed?: string
  gasPrice?: string
  value?: string
  from: string
  to: string
  confirmations?: number
  details?: {
    referrer?: string
    amount?: string
    profileData?: any
  }
}

export function useTransactionTracker() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [currentTransaction, setCurrentTransaction] = useState<Transaction | null>(null)

  const generateMockTransactions = useCallback((): Transaction[] => {
    const types: Transaction["type"][] = ["gm", "referral", "claim", "profile"]
    const statuses: Transaction["status"][] = ["pending", "confirmed", "failed"]
    const mockTxs: Transaction[] = []

    // Generate 20 mock transactions with variety
    for (let i = 0; i < 20; i++) {
      const type = types[Math.floor(Math.random() * types.length)]
      const status = statuses[Math.floor(Math.random() * statuses.length)]
      const daysAgo = Math.floor(Math.random() * 90) // Random date within last 90 days
      const timestamp = Date.now() - daysAgo * 24 * 60 * 60 * 1000

      let value = "0"
      let details = {}

      switch (type) {
        case "gm":
          value = "1000000000000000000" // 1 MON
          details = { amount: "1.0" }
          break
        case "referral":
          value = "500000000000000000" // 0.5 MON
          details = {
            referrer: `0x${Math.random().toString(16).substr(2, 40)}`,
            amount: "0.5",
          }
          break
        case "claim":
          const claimAmount = (Math.random() * 5 + 0.1).toFixed(2)
          value = (Number.parseFloat(claimAmount) * Math.pow(10, 18)).toString()
          details = { amount: claimAmount }
          break
        case "profile":
          details = { profileData: "Updated social handles" }
          break
      }

      mockTxs.push({
        hash: `0x${Math.random().toString(16).substr(2, 64)}`,
        type,
        status,
        timestamp,
        blockNumber: status === "confirmed" ? Math.floor(Math.random() * 1000000) + 1000000 : undefined,
        gasUsed: status !== "pending" ? (Math.floor(Math.random() * 50000) + 21000).toString() : undefined,
        gasPrice: status !== "pending" ? (Math.random() * 3 + 1).toFixed(1) : undefined,
        value,
        from: window.ethereum?.selectedAddress || "0x...",
        to: "0xabcdef1234567890abcdef1234567890abcdef12",
        confirmations: status === "confirmed" ? Math.floor(Math.random() * 50) + 12 : Math.floor(Math.random() * 12),
        details,
      })
    }

    return mockTxs.sort((a, b) => b.timestamp - a.timestamp) // Sort by newest first
  }, [])

  const addTransaction = useCallback(
    (transaction: Transaction) => {
      setTransactions((prev) => {
        // If this is the first transaction, also add some mock historical data
        if (prev.length === 0) {
          const mockTransactions = generateMockTransactions()
          return [transaction, ...mockTransactions]
        }
        return [transaction, ...prev]
      })
      setCurrentTransaction(transaction)
    },
    [generateMockTransactions],
  )

  const updateTransaction = useCallback(
    (hash: string, updates: Partial<Transaction>) => {
      setTransactions((prev) => prev.map((tx) => (tx.hash === hash ? { ...tx, ...updates } : tx)))

      if (currentTransaction?.hash === hash) {
        setCurrentTransaction((prev) => (prev ? { ...prev, ...updates } : null))
      }
    },
    [currentTransaction],
  )

  const trackGMTransaction = useCallback(
    async (txHash: string) => {
      const transaction = {
        hash: txHash,
        type: "gm",
        status: "pending",
        timestamp: Date.now(),
        value: "1000000000000000000", // 1 MON in wei
        from: window.ethereum?.selectedAddress || "0x...",
        to: "0xF0d52c2Ff5f4779a0D10D81824b2F7EB40c2EDb9", // Contract address
        details: { amount: "1.0" },
        confirmations: 0,
      }

      addTransaction(transaction)

      // Simulate transaction confirmation
      setTimeout(() => {
        updateTransaction(txHash, {
          status: "confirmed",
          blockNumber: Math.floor(Math.random() * 1000000) + 1000000,
          gasUsed: "21000",
          gasPrice: "2.5",
          confirmations: 12,
        })
      }, 5000)

      return transaction
    },
    [addTransaction, updateTransaction],
  )

  const trackReferralTransaction = useCallback(
    async (txHash: string, referrer: string) => {
      const transaction = {
        hash: txHash,
        type: "referral",
        status: "pending",
        timestamp: Date.now(),
        value: "500000000000000000", // 0.5 MON in wei
        from: window.ethereum?.selectedAddress || "0x...",
        to: "0xF0d52c2Ff5f4779a0D10D81824b2F7EB40c2EDb9", // Contract address
        details: { referrer, amount: "0.5" },
        confirmations: 0,
      }

      addTransaction(transaction)

      // Simulate transaction confirmation
      setTimeout(() => {
        updateTransaction(txHash, {
          status: "confirmed",
          blockNumber: Math.floor(Math.random() * 1000000) + 1000000,
          gasUsed: "35000",
          gasPrice: "2.2",
          confirmations: 12,
        })
      }, 6000)

      return transaction
    },
    [addTransaction, updateTransaction],
  )

  const trackClaimTransaction = useCallback(
    async (txHash: string, amount: string) => {
      const transaction = {
        hash: txHash,
        type: "claim",
        status: "pending",
        timestamp: Date.now(),
        value: (Number.parseFloat(amount) * Math.pow(10, 18)).toString(), // Convert to wei
        from: window.ethereum?.selectedAddress || "0x...",
        to: "0xF0d52c2Ff5f4779a0D10D81824b2F7EB40c2EDb9", // Contract address
        details: { amount },
        confirmations: 0,
      }

      addTransaction(transaction)

      // Simulate transaction confirmation
      setTimeout(() => {
        updateTransaction(txHash, {
          status: "confirmed",
          blockNumber: Math.floor(Math.random() * 1000000) + 1000000,
          gasUsed: "45000",
          gasPrice: "2.8",
          confirmations: 12,
        })
      }, 7000)

      return transaction
    },
    [addTransaction, updateTransaction],
  )

  const clearCurrentTransaction = useCallback(() => {
    setCurrentTransaction(null)
  }, [])

  return {
    transactions,
    currentTransaction,
    trackGMTransaction,
    trackReferralTransaction,
    trackClaimTransaction,
    clearCurrentTransaction,
    updateTransaction,
  }
}
