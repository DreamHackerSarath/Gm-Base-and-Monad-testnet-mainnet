// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/**
 * @title GM Contract for Monad Ecosystem
 * @dev A contract for daily GM interactions with referral rewards and profile management
 */
contract GM is Ownable, ReentrancyGuard {
    
    /// @dev Profile structure for user information
    struct Profile {
        string xUsername;
        string discordUsername;
        string telegramUsername;
        address evmMonadAddress;
        string solanaAddress;
    }
    
    /// @dev Mapping from user address to their profile
    mapping(address => Profile) public profiles;
    
    /// @dev Mapping from user address to pending referral rewards
    mapping(address => uint256) public pendingRewards;
    
    /// @dev Mapping from user address to last claim timestamp
    mapping(address => uint256) public lastClaimTime;
    
    /// @dev Mapping from user address to last GM timestamp
    mapping(address => uint256) public lastGMTime;
    
    /// @dev Total number of GMs sent
    uint256 public totalGMs;
    
    /// @dev Owner wallet address for fee collection
    address public constant OWNER_WALLET = 0xF0d52c2Ff5f4779a0D10D81824b2F7EB40c2EDb9;
    
    /// @dev Claim cooldown period (60 days)
    uint256 public constant CLAIM_COOLDOWN = 60 days;
    
    /// @dev Daily GM cooldown (24 hours)
    uint256 public constant GM_COOLDOWN = 24 hours;
    
    /// @dev GM fee (1 MONAD)
    uint256 public constant GM_FEE = 1 ether;
    
    /// @dev Referral GM fee (0.5 MONAD)
    uint256 public constant REFERRAL_GM_FEE = 0.5 ether;
    
    /// @dev Events
    event GMSent(address indexed from, uint256 timestamp);
    event GMReferred(address indexed from, address indexed referrer, uint256 timestamp);
    event RewardsClaimed(address indexed user, uint256 amount);
    event ProfileUpdated(
        address indexed user,
        string xUsername,
        string discordUsername,
        string telegramUsername,
        address evmMonadAddress,
        string solanaAddress
    );
    
    constructor() Ownable(msg.sender) {}
    
    /**
     * @dev Send a daily GM for 1 MONAD
     * @notice Users can only send one GM per day
     */
    function gm() external payable nonReentrant {
        require(msg.value == GM_FEE, "GM: Incorrect fee amount");
        require(
            block.timestamp >= lastGMTime[msg.sender] + GM_COOLDOWN,
            "GM: Already sent GM today"
        );
        
        lastGMTime[msg.sender] = block.timestamp;
        totalGMs++;
        
        // Forward full fee to owner wallet
        (bool success, ) = OWNER_WALLET.call{value: msg.value}("");
        require(success, "GM: Fee transfer failed");
        
        emit GMSent(msg.sender, block.timestamp);
    }
    
    /**
     * @dev Send a referral GM for 0.5 MONAD
     * @param referrer Address of the user who referred this GM
     */
    function referGM(address referrer) external payable nonReentrant {
        require(msg.value == REFERRAL_GM_FEE, "GM: Incorrect referral fee amount");
        require(referrer != msg.sender, "GM: Cannot refer yourself");
        require(referrer != address(0), "GM: Invalid referrer address");
        
        // Split payment: 0.25 MONAD to owner, 0.25 MONAD as referral reward
        uint256 ownerShare = msg.value / 2;
        uint256 referralReward = msg.value - ownerShare;
        
        // Forward owner share immediately
        (bool success, ) = OWNER_WALLET.call{value: ownerShare}("");
        require(success, "GM: Owner share transfer failed");
        
        // Add referral reward to pending rewards
        pendingRewards[referrer] += referralReward;
        
        emit GMReferred(msg.sender, referrer, block.timestamp);
    }
    
    /**
     * @dev Claim accumulated referral rewards
     * @notice Can only be called once every 60 days
     */
    function claimRewards() external nonReentrant {
        require(pendingRewards[msg.sender] > 0, "GM: No rewards to claim");
        require(
            block.timestamp >= lastClaimTime[msg.sender] + CLAIM_COOLDOWN,
            "GM: Claim cooldown not met"
        );
        
        uint256 rewards = pendingRewards[msg.sender];
        pendingRewards[msg.sender] = 0;
        lastClaimTime[msg.sender] = block.timestamp;
        
        (bool success, ) = msg.sender.call{value: rewards}("");
        require(success, "GM: Reward transfer failed");
        
        emit RewardsClaimed(msg.sender, rewards);
    }
    
    /**
     * @dev Set or update user profile
     * @param xUsername X (Twitter) username
     * @param discordUsername Discord username
     * @param telegramUsername Telegram username
     * @param evmMonadAddress EVM Monad address
     * @param solanaAddress Solana address (Base58 string)
     */
    function setProfile(
        string calldata xUsername,
        string calldata discordUsername,
        string calldata telegramUsername,
        address evmMonadAddress,
        string calldata solanaAddress
    ) external {
        profiles[msg.sender] = Profile({
            xUsername: xUsername,
            discordUsername: discordUsername,
            telegramUsername: telegramUsername,
            evmMonadAddress: evmMonadAddress,
            solanaAddress: solanaAddress
        });
        
        emit ProfileUpdated(
            msg.sender,
            xUsername,
            discordUsername,
            telegramUsername,
            evmMonadAddress,
            solanaAddress
        );
    }
    
    /**
     * @dev Get total number of GMs sent
     * @return Total GM count
     */
    function gmCount() external view returns (uint256) {
        return totalGMs;
    }
    
    /**
     * @dev Get pending referral rewards for an address
     * @param user Address to check rewards for
     * @return Pending reward amount
     */
    function referralRewards(address user) external view returns (uint256) {
        return pendingRewards[user];
    }
    
    /**
     * @dev Get next claim time for an address
     * @param user Address to check next claim time for
     * @return Timestamp when rewards can next be claimed
     */
    function nextClaimTime(address user) external view returns (uint256) {
        return lastClaimTime[user] + CLAIM_COOLDOWN;
    }
    
    /**
     * @dev Check if user can send GM today
     * @param user Address to check
     * @return True if user can send GM
     */
    function canSendGM(address user) external view returns (bool) {
        return block.timestamp >= lastGMTime[user] + GM_COOLDOWN;
    }
    
    /**
     * @dev Emergency withdrawal function for owner (non-fee funds only)
     * @param amount Amount to withdraw
     */
    function emergencyWithdraw(uint256 amount) external onlyOwner {
        require(amount <= address(this).balance, "GM: Insufficient balance");
        (bool success, ) = owner().call{value: amount}("");
        require(success, "GM: Withdrawal failed");
    }
    
    /**
     * @dev Receive function to accept direct payments
     */
    receive() external payable {}
}
