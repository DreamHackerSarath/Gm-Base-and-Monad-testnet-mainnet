"use client"

import { useState, useEffect } from "react"
import { ConnectWallet } from "@/components/connect-wallet"
import { GMButton } from "@/components/gm-button"
import { Leaderboard } from "@/components/leaderboard"
import { ProfileModal } from "@/components/profile-modal"
import { StreakCounter } from "@/components/streak-counter"
import { ReferralSystem } from "@/components/referral-system"
import { FaucetModal } from "@/components/faucet-modal"
import { NetworkStatus } from "@/components/network-status"
import { EcosystemIntegration } from "@/components/ecosystem-integration"
import { MonadStats } from "@/components/monad-stats"
import { TransactionHistory } from "@/components/transaction-history"
import { TransactionModal } from "@/components/transaction-modal"
import { useWeb3 } from "@/hooks/use-web3"
import { useContract } from "@/hooks/use-contract"
import { useTransactionTracker } from "@/hooks/use-transaction-tracker"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Settings, Zap, Droplets, ExternalLink, Coins, Palette, Gamepad2, History } from "lucide-react"
import { NetworkInfo } from "@/components/network-info"
import { GMStats } from "@/components/gm-stats" // Added import for GMStats

export default function HomePage() {
  const { account, isConnected, balance } = useWeb3()
  const { getTotalGMs, getUserStreak, getPendingRewards } = useContract()
  const {
    transactions,
    currentTransaction,
    trackGMTransaction,
    trackReferralTransaction,
    trackClaimTransaction,
    clearCurrentTransaction,
  } = useTransactionTracker()

  const [showProfile, setShowProfile] = useState(false)
  const [showFaucet, setShowFaucet] = useState(false)
  const [showTransactionModal, setShowTransactionModal] = useState(false)
  const [gmCount, setGmCount] = useState(0)
  const [userStreak, setUserStreak] = useState(0)
  const [pendingRewards, setPendingRewards] = useState("0")

  useEffect(() => {
    if (isConnected) {
      loadContractData()
    }
  }, [isConnected])

  useEffect(() => {
    if (currentTransaction) {
      setShowTransactionModal(true)
    }
  }, [currentTransaction])

  const loadContractData = async () => {
    try {
      const totalGMs = await getTotalGMs()
      const streak = await getUserStreak()
      const rewards = await getPendingRewards()

      setGmCount(totalGMs)
      setUserStreak(streak)
      setPendingRewards(rewards)
    } catch (error) {
      console.error("Error loading contract data:", error)
    }
  }

  const handleGMSent = async () => {
    // Generate mock transaction hash
    const txHash = `0x${Math.random().toString(16).substr(2, 64)}`

    // Track the transaction
    await trackGMTransaction(txHash)

    // Update local state
    setGmCount((prev) => prev + 1)
    setUserStreak((prev) => prev + 1)
    loadContractData()
  }

  const handleReferralSent = async (referrer: string) => {
    // Generate mock transaction hash
    const txHash = `0x${Math.random().toString(16).substr(2, 64)}`

    // Track the transaction
    await trackReferralTransaction(txHash, referrer)

    loadContractData()
  }

  const handleRewardsClaimed = async (amount: string) => {
    // Generate mock transaction hash
    const txHash = `0x${Math.random().toString(16).substr(2, 64)}`

    // Track the transaction
    await trackClaimTransaction(txHash, amount)

    setPendingRewards("0")
    loadContractData()
  }

  const needsTestnetTokens = balance && Number.parseFloat(balance) < 1

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-pink-600">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <header className="flex justify-between items-center mb-8">
          <div className="flex items-center space-x-4">
            <img src="/images/monad-logo.jpg" alt="Monad Logo" className="w-10 h-10 rounded-lg" />
            <div className="flex items-center space-x-2">
              <h1 className="text-4xl font-bold text-white">gm</h1>
              <span className="text-purple-200 text-sm font-medium">Monad</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <NetworkStatus />
            {isConnected && needsTestnetTokens && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFaucet(true)}
                className="bg-blue-600/20 border-blue-400/50 text-blue-200 hover:bg-blue-600/30"
              >
                <Droplets className="w-4 h-4 mr-2" />
                Get Testnet MON
              </Button>
            )}
            {isConnected && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowProfile(true)}
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                <Settings className="w-4 h-4 mr-2" />
                Profile
              </Button>
            )}
            <ConnectWallet />
          </div>
        </header>

        {!isConnected ? (
          /* Welcome Screen */
          <div className="text-center py-20">
            <div className="flex items-center justify-center mb-6">
              <img src="/images/monad-logo.jpg" alt="Monad Logo" className="w-16 h-16 rounded-xl mr-4" />
              <h2 className="text-6xl font-bold text-white">gm</h2>
            </div>
            <p className="text-xl text-purple-200 mb-8 max-w-2xl mx-auto">
              Say good morning to the Monad ecosystem. Built on the fastest EVM-compatible blockchain with 10,000 TPS.
              Participate daily for 1 MON, refer friends for rewards, and explore the growing ecosystem.
            </p>

            {/* Monad Ecosystem Features */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-5xl mx-auto mb-12">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <Zap className="w-8 h-8 text-yellow-400 mb-4 mx-auto" />
                <h3 className="text-lg font-semibold text-white mb-2">Daily GM</h3>
                <p className="text-purple-200 text-sm">Say gm every day for 1 MON and build your streak</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <Coins className="w-8 h-8 text-green-400 mb-4 mx-auto" />
                <h3 className="text-lg font-semibold text-white mb-2">DeFi Integration</h3>
                <p className="text-purple-200 text-sm">Access DEXs, lending protocols, and yield farming</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <Palette className="w-8 h-8 text-pink-400 mb-4 mx-auto" />
                <h3 className="text-lg font-semibold text-white mb-2">NFT Marketplace</h3>
                <p className="text-purple-200 text-sm">Trade and collect NFTs on Monad's fast network</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
                <Gamepad2 className="w-8 h-8 text-blue-400 mb-4 mx-auto" />
                <h3 className="text-lg font-semibold text-white mb-2">GameFi</h3>
                <p className="text-purple-200 text-sm">Play games and earn rewards in the ecosystem</p>
              </div>
            </div>

            {/* Monad Info */}
            <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 max-w-2xl mx-auto mb-8 border border-white/10">
              <h3 className="text-lg font-semibold text-white mb-3">Powered by Monad</h3>
              <p className="text-purple-200 text-sm mb-4">
                Full EVM-compatibility with 10,000 TPS. Build without constraints on the next-generation blockchain.
              </p>
              <div className="flex justify-center space-x-4">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.open("https://testnet.monad.xyz/", "_blank")}
                  className="bg-purple-600/20 border-purple-400/50 text-purple-200 hover:bg-purple-600/30"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Monad Testnet
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.open("https://developers.monad.xyz/", "_blank")}
                  className="bg-purple-600/20 border-purple-400/50 text-purple-200 hover:bg-purple-600/30"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Developer Docs
                </Button>
              </div>
            </div>

            {/* Network Information */}
            <div className="max-w-4xl mx-auto mb-8">
              <NetworkInfo />
            </div>
          </div>
        ) : (
          /* Main App */
          <div>
            {/* Monad Network Stats */}
            <MonadStats />

            {/* GM Platform Stats */}
            <div className="mb-8">
              <GMStats />
            </div>

            <Tabs defaultValue="gm" className="w-full">
              <TabsList className="grid w-full grid-cols-5 bg-white/10 backdrop-blur-sm border border-white/20">
                <TabsTrigger value="gm" className="data-[state=active]:bg-white/20 text-white">
                  GM Platform
                </TabsTrigger>
                <TabsTrigger value="transactions" className="data-[state=active]:bg-white/20 text-white">
                  <History className="w-4 h-4 mr-2" />
                  Transactions
                </TabsTrigger>
                <TabsTrigger value="ecosystem" className="data-[state=active]:bg-white/20 text-white">
                  Ecosystem
                </TabsTrigger>
                <TabsTrigger value="defi" className="data-[state=active]:bg-white/20 text-white">
                  DeFi
                </TabsTrigger>
                <TabsTrigger value="nft" className="data-[state=active]:bg-white/20 text-white">
                  NFTs
                </TabsTrigger>
              </TabsList>

              <TabsContent value="gm" className="mt-8">
                {/* Stats Bar */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20 text-center">
                    <p className="text-2xl font-bold text-white">{gmCount}</p>
                    <p className="text-purple-200 text-sm">Total GMs</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20 text-center">
                    <p className="text-2xl font-bold text-white">{userStreak}</p>
                    <p className="text-purple-200 text-sm">Your Streak</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20 text-center">
                    <p className="text-2xl font-bold text-white">{pendingRewards}</p>
                    <p className="text-purple-200 text-sm">Pending MON</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20 text-center">
                    <p className="text-2xl font-bold text-white">{balance || "0"}</p>
                    <p className="text-purple-200 text-sm">Wallet Balance</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Left Column - GM Button & Streak */}
                  <div className="lg:col-span-2 space-y-6">
                    <StreakCounter streak={userStreak} />
                    <GMButton onGMSent={handleGMSent} />
                    <ReferralSystem
                      pendingRewards={pendingRewards}
                      onRewardsClaimed={() => handleRewardsClaimed(pendingRewards)}
                      onReferralSent={handleReferralSent}
                    />
                  </div>

                  {/* Right Column - Leaderboard */}
                  <div>
                    <Leaderboard />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="transactions" className="mt-8">
                <TransactionHistory userAddress={account} />
              </TabsContent>

              <TabsContent value="ecosystem" className="mt-8">
                <EcosystemIntegration />
              </TabsContent>

              <TabsContent value="defi" className="mt-8">
                <div className="text-center py-20">
                  <h2 className="text-3xl font-bold text-white mb-4">DeFi on Monad</h2>
                  <p className="text-purple-200 mb-8">Coming soon - Decentralized Finance protocols</p>
                </div>
              </TabsContent>

              <TabsContent value="nft" className="mt-8">
                <div className="text-center py-20">
                  <h2 className="text-3xl font-bold text-white mb-4">NFT Marketplace</h2>
                  <p className="text-purple-200 mb-8">Coming soon - NFT trading and collections</p>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        )}

        {/* Modals */}
        {showProfile && <ProfileModal isOpen={showProfile} onClose={() => setShowProfile(false)} />}
        {showFaucet && <FaucetModal isOpen={showFaucet} onClose={() => setShowFaucet(false)} />}
        {showTransactionModal && (
          <TransactionModal
            isOpen={showTransactionModal}
            onClose={() => {
              setShowTransactionModal(false)
              clearCurrentTransaction()
            }}
            transaction={currentTransaction}
          />
        )}
      </div>
    </div>
  )
}
