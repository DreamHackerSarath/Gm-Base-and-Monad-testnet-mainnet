"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useContract } from "@/hooks/use-contract"
import { toast } from "@/hooks/use-toast"

interface ProfileModalProps {
  isOpen: boolean
  onClose: () => void
}

interface Profile {
  xUsername: string
  discordUsername: string
  telegramUsername: string
  evmMonadAddress: string
  solanaAddress: string
}

export function ProfileModal({ isOpen, onClose }: ProfileModalProps) {
  const [profile, setProfile] = useState<Profile>({
    xUsername: "",
    discordUsername: "",
    telegramUsername: "",
    evmMonadAddress: "",
    solanaAddress: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const { updateProfile, getProfile } = useContract()

  useEffect(() => {
    if (isOpen) {
      loadProfile()
    }
  }, [isOpen])

  const loadProfile = async () => {
    try {
      const userProfile = await getProfile()
      if (userProfile) {
        setProfile(userProfile)
      }
    } catch (error) {
      console.error("Failed to load profile:", error)
    }
  }

  const handleSave = async () => {
    setIsLoading(true)
    try {
      await updateProfile(profile)
      toast({
        title: "Profile updated!",
        description: "Your profile has been saved on-chain",
      })
      onClose()
    } catch (error) {
      toast({
        title: "Failed to update profile",
        description: "Please try again",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-purple-900 border-purple-700 text-white max-w-md">
        <DialogHeader>
          <DialogTitle>Update Profile</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="xUsername" className="text-purple-200">
              X Username
            </Label>
            <Input
              id="xUsername"
              value={profile.xUsername}
              onChange={(e) => setProfile((prev) => ({ ...prev, xUsername: e.target.value }))}
              placeholder="@username"
              className="bg-white/5 border-white/20 text-white placeholder:text-purple-300"
            />
          </div>

          <div>
            <Label htmlFor="discordUsername" className="text-purple-200">
              Discord Username
            </Label>
            <Input
              id="discordUsername"
              value={profile.discordUsername}
              onChange={(e) => setProfile((prev) => ({ ...prev, discordUsername: e.target.value }))}
              placeholder="username#1234"
              className="bg-white/5 border-white/20 text-white placeholder:text-purple-300"
            />
          </div>

          <div>
            <Label htmlFor="telegramUsername" className="text-purple-200">
              Telegram Username
            </Label>
            <Input
              id="telegramUsername"
              value={profile.telegramUsername}
              onChange={(e) => setProfile((prev) => ({ ...prev, telegramUsername: e.target.value }))}
              placeholder="@username"
              className="bg-white/5 border-white/20 text-white placeholder:text-purple-300"
            />
          </div>

          <div>
            <Label htmlFor="evmMonadAddress" className="text-purple-200">
              EVM Monad Address
            </Label>
            <Input
              id="evmMonadAddress"
              value={profile.evmMonadAddress}
              onChange={(e) => setProfile((prev) => ({ ...prev, evmMonadAddress: e.target.value }))}
              placeholder="0x..."
              className="bg-white/5 border-white/20 text-white placeholder:text-purple-300"
            />
          </div>

          <div>
            <Label htmlFor="solanaAddress" className="text-purple-200">
              Solana Address
            </Label>
            <Input
              id="solanaAddress"
              value={profile.solanaAddress}
              onChange={(e) => setProfile((prev) => ({ ...prev, solanaAddress: e.target.value }))}
              placeholder="Base58 address"
              className="bg-white/5 border-white/20 text-white placeholder:text-purple-300"
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1 bg-white/5 border-white/20 text-white hover:bg-white/10"
            >
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={isLoading} className="flex-1 bg-purple-600 hover:bg-purple-700">
              {isLoading ? "Saving..." : "Save Profile"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
