"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Flame } from "lucide-react"

interface StreakCounterProps {
  streak: number
}

export function StreakCounter({ streak }: StreakCounterProps) {
  return (
    <Card className="bg-white/10 backdrop-blur-sm border-white/20">
      <CardContent className="p-6 text-center">
        <div className="flex items-center justify-center space-x-3">
          <Flame className="w-8 h-8 text-orange-500" />
          <div>
            <p className="text-3xl font-bold text-white">{streak}</p>
            <p className="text-purple-200 text-sm">Day Streak</p>
          </div>
        </div>
        <p className="text-purple-300 text-sm mt-2">Keep it going! Don't break the chain.</p>
      </CardContent>
    </Card>
  )
}
