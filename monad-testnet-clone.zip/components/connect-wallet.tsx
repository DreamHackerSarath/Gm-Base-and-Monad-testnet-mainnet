"use client"
import { Button } from "@/components/ui/button"
import { useWeb3 } from "@/hooks/use-web3"
import { Wallet } from "lucide-react"

export function ConnectWallet() {
  const { account, isConnected, connect, disconnect } = useWeb3()

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`
  }

  if (isConnected && account) {
    return (
      <Button
        variant="outline"
        onClick={disconnect}
        className="bg-white/10 border-white/20 text-white hover:bg-white/20"
      >
        {formatAddress(account)}
      </Button>
    )
  }

  return (
    <Button onClick={connect} className="bg-white text-purple-900 hover:bg-white/90 font-semibold">
      <Wallet className="w-4 h-4 mr-2" />
      Connect Wallet
    </Button>
  )
}
