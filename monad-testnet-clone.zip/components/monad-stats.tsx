"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Activity, Zap, Users, TrendingUp } from "lucide-react"

export function MonadStats() {
  const [stats, setStats] = useState({
    tps: 0,
    blockTime: 0,
    totalTransactions: 0,
    activeUsers: 0,
    gasPrice: 0,
  })

  useEffect(() => {
    // Simulate real-time stats - in production, fetch from Monad RPC
    const interval = setInterval(() => {
      setStats({
        tps: Math.floor(Math.random() * 2000) + 8000, // 8000-10000 TPS
        blockTime: Math.random() * 0.5 + 0.5, // 0.5-1.0 seconds
        totalTransactions: Math.floor(Math.random() * 1000000) + 5000000,
        activeUsers: Math.floor(Math.random() * 10000) + 50000,
        gasPrice: Math.random() * 5 + 1, // 1-6 gwei
      })
    }, 3000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-purple-200 flex items-center">
            <Zap className="w-4 h-4 mr-2" />
            TPS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">{stats.tps.toLocaleString()}</div>
          <Badge variant="secondary" className="bg-green-600/20 text-green-200 text-xs">
            Live
          </Badge>
        </CardContent>
      </Card>

      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-purple-200 flex items-center">
            <Activity className="w-4 h-4 mr-2" />
            Block Time
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">{stats.blockTime.toFixed(1)}s</div>
          <Badge variant="secondary" className="bg-blue-600/20 text-blue-200 text-xs">
            Fast
          </Badge>
        </CardContent>
      </Card>

      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-purple-200 flex items-center">
            <TrendingUp className="w-4 h-4 mr-2" />
            Total TXs
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">{(stats.totalTransactions / 1000000).toFixed(1)}M</div>
          <Badge variant="secondary" className="bg-purple-600/20 text-purple-200 text-xs">
            Testnet
          </Badge>
        </CardContent>
      </Card>

      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-purple-200 flex items-center">
            <Users className="w-4 h-4 mr-2" />
            Active Users
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">{(stats.activeUsers / 1000).toFixed(0)}K</div>
          <Badge variant="secondary" className="bg-orange-600/20 text-orange-200 text-xs">
            Growing
          </Badge>
        </CardContent>
      </Card>

      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium text-purple-200">Gas Price</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-white">{stats.gasPrice.toFixed(1)}</div>
          <Badge variant="secondary" className="bg-green-600/20 text-green-200 text-xs">
            Low
          </Badge>
        </CardContent>
      </Card>
    </div>
  )
}
