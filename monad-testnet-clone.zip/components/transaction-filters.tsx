"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Calendar, Filter, X, RotateCcw } from "lucide-react"

export interface TransactionFilters {
  type: string[]
  status: string[]
  dateFrom: string
  dateTo: string
  amountMin: string
  amountMax: string
}

interface TransactionFiltersProps {
  filters: TransactionFilters
  onFiltersChange: (filters: TransactionFilters) => void
  onClearFilters: () => void
  transactionCounts: {
    total: number
    filtered: number
    byType: Record<string, number>
    byStatus: Record<string, number>
  }
}

export function TransactionFiltersComponent({
  filters,
  onFiltersChange,
  onClearFilters,
  transactionCounts,
}: TransactionFiltersProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  const transactionTypes = [
    { value: "gm", label: "Daily GM", icon: "☀️" },
    { value: "referral", label: "Referral GM", icon: "👥" },
    { value: "claim", label: "Claim Rewards", icon: "💰" },
    { value: "profile", label: "Update Profile", icon: "👤" },
  ]

  const statusTypes = [
    { value: "pending", label: "Pending", color: "bg-yellow-600/20 text-yellow-200 border-yellow-400/50" },
    { value: "confirmed", label: "Confirmed", color: "bg-green-600/20 text-green-200 border-green-400/50" },
    { value: "failed", label: "Failed", color: "bg-red-600/20 text-red-200 border-red-400/50" },
  ]

  const updateFilters = (key: keyof TransactionFilters, value: any) => {
    onFiltersChange({
      ...filters,
      [key]: value,
    })
  }

  const toggleTypeFilter = (type: string) => {
    const newTypes = filters.type.includes(type) ? filters.type.filter((t) => t !== type) : [...filters.type, type]
    updateFilters("type", newTypes)
  }

  const toggleStatusFilter = (status: string) => {
    const newStatuses = filters.status.includes(status)
      ? filters.status.filter((s) => s !== status)
      : [...filters.status, status]
    updateFilters("status", newStatuses)
  }

  const hasActiveFilters =
    filters.type.length > 0 ||
    filters.status.length > 0 ||
    filters.dateFrom ||
    filters.dateTo ||
    filters.amountMin ||
    filters.amountMax

  const getActiveFilterCount = () => {
    let count = 0
    if (filters.type.length > 0) count++
    if (filters.status.length > 0) count++
    if (filters.dateFrom || filters.dateTo) count++
    if (filters.amountMin || filters.amountMax) count++
    return count
  }

  return (
    <Card className="bg-white/10 backdrop-blur-sm border-white/20 mb-6">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white flex items-center">
            <Filter className="w-5 h-5 mr-2" />
            Transaction Filters
            {hasActiveFilters && (
              <Badge variant="secondary" className="ml-2 bg-purple-600/50 text-white">
                {getActiveFilterCount()} active
              </Badge>
            )}
          </CardTitle>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsExpanded(!isExpanded)}
              className="bg-white/5 border-white/20 text-white hover:bg-white/10"
            >
              {isExpanded ? "Collapse" : "Expand"}
            </Button>
            {hasActiveFilters && (
              <Button
                variant="outline"
                size="sm"
                onClick={onClearFilters}
                className="bg-red-600/20 border-red-400/50 text-red-200 hover:bg-red-600/30"
              >
                <RotateCcw className="w-4 h-4 mr-1" />
                Clear
              </Button>
            )}
          </div>
        </div>

        {/* Quick Stats */}
        <div className="flex items-center space-x-4 text-sm text-purple-200">
          <span>
            Showing {transactionCounts.filtered} of {transactionCounts.total} transactions
          </span>
        </div>
      </CardHeader>

      {isExpanded && (
        <CardContent className="space-y-6">
          {/* Transaction Type Filter */}
          <div>
            <Label className="text-purple-200 mb-3 block">Transaction Type</Label>
            <div className="flex flex-wrap gap-2">
              {transactionTypes.map((type) => (
                <Button
                  key={type.value}
                  variant={filters.type.includes(type.value) ? "default" : "outline"}
                  size="sm"
                  onClick={() => toggleTypeFilter(type.value)}
                  className={
                    filters.type.includes(type.value)
                      ? "bg-purple-600 hover:bg-purple-700 text-white"
                      : "bg-white/5 border-white/20 text-white hover:bg-white/10"
                  }
                >
                  <span className="mr-2">{type.icon}</span>
                  {type.label}
                  <Badge variant="secondary" className="ml-2 bg-white/20 text-xs">
                    {transactionCounts.byType[type.value] || 0}
                  </Badge>
                </Button>
              ))}
            </div>
          </div>

          {/* Status Filter */}
          <div>
            <Label className="text-purple-200 mb-3 block">Status</Label>
            <div className="flex flex-wrap gap-2">
              {statusTypes.map((status) => (
                <Button
                  key={status.value}
                  variant={filters.status.includes(status.value) ? "default" : "outline"}
                  size="sm"
                  onClick={() => toggleStatusFilter(status.value)}
                  className={
                    filters.status.includes(status.value)
                      ? status.color
                      : "bg-white/5 border-white/20 text-white hover:bg-white/10"
                  }
                >
                  {status.label}
                  <Badge variant="secondary" className="ml-2 bg-white/20 text-xs">
                    {transactionCounts.byStatus[status.value] || 0}
                  </Badge>
                </Button>
              ))}
            </div>
          </div>

          {/* Date Range Filter */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="dateFrom" className="text-purple-200 mb-2 block">
                From Date
              </Label>
              <Input
                id="dateFrom"
                type="date"
                value={filters.dateFrom}
                onChange={(e) => updateFilters("dateFrom", e.target.value)}
                className="bg-white/5 border-white/20 text-white"
              />
            </div>
            <div>
              <Label htmlFor="dateTo" className="text-purple-200 mb-2 block">
                To Date
              </Label>
              <Input
                id="dateTo"
                type="date"
                value={filters.dateTo}
                onChange={(e) => updateFilters("dateTo", e.target.value)}
                className="bg-white/5 border-white/20 text-white"
              />
            </div>
          </div>

          {/* Amount Range Filter */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="amountMin" className="text-purple-200 mb-2 block">
                Min Amount (MON)
              </Label>
              <Input
                id="amountMin"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={filters.amountMin}
                onChange={(e) => updateFilters("amountMin", e.target.value)}
                className="bg-white/5 border-white/20 text-white placeholder:text-purple-300"
              />
            </div>
            <div>
              <Label htmlFor="amountMax" className="text-purple-200 mb-2 block">
                Max Amount (MON)
              </Label>
              <Input
                id="amountMax"
                type="number"
                step="0.01"
                placeholder="100.00"
                value={filters.amountMax}
                onChange={(e) => updateFilters("amountMax", e.target.value)}
                className="bg-white/5 border-white/20 text-white placeholder:text-purple-300"
              />
            </div>
          </div>

          {/* Quick Date Presets */}
          <div>
            <Label className="text-purple-200 mb-3 block">Quick Date Filters</Label>
            <div className="flex flex-wrap gap-2">
              {[
                { label: "Today", days: 0 },
                { label: "Last 7 days", days: 7 },
                { label: "Last 30 days", days: 30 },
                { label: "Last 90 days", days: 90 },
              ].map((preset) => (
                <Button
                  key={preset.label}
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const today = new Date()
                    const fromDate = new Date(today)
                    fromDate.setDate(today.getDate() - preset.days)

                    updateFilters("dateFrom", fromDate.toISOString().split("T")[0])
                    updateFilters("dateTo", today.toISOString().split("T")[0])
                  }}
                  className="bg-white/5 border-white/20 text-white hover:bg-white/10"
                >
                  <Calendar className="w-3 h-3 mr-1" />
                  {preset.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Active Filters Summary */}
          {hasActiveFilters && (
            <div className="bg-white/5 rounded-lg p-4 border border-white/10">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-white font-medium">Active Filters</h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClearFilters}
                  className="text-red-300 hover:text-red-200 hover:bg-red-600/20"
                >
                  <X className="w-4 h-4 mr-1" />
                  Clear All
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {filters.type.map((type) => (
                  <Badge
                    key={`type-${type}`}
                    variant="secondary"
                    className="bg-purple-600/30 text-purple-200 border border-purple-400/50"
                  >
                    Type: {transactionTypes.find((t) => t.value === type)?.label}
                    <button
                      onClick={() => toggleTypeFilter(type)}
                      className="ml-2 hover:bg-white/20 rounded-full p-0.5"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
                {filters.status.map((status) => (
                  <Badge
                    key={`status-${status}`}
                    variant="secondary"
                    className="bg-blue-600/30 text-blue-200 border border-blue-400/50"
                  >
                    Status: {statusTypes.find((s) => s.value === status)?.label}
                    <button
                      onClick={() => toggleStatusFilter(status)}
                      className="ml-2 hover:bg-white/20 rounded-full p-0.5"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
                {(filters.dateFrom || filters.dateTo) && (
                  <Badge variant="secondary" className="bg-green-600/30 text-green-200 border border-green-400/50">
                    Date: {filters.dateFrom || "Start"} → {filters.dateTo || "End"}
                    <button
                      onClick={() => {
                        updateFilters("dateFrom", "")
                        updateFilters("dateTo", "")
                      }}
                      className="ml-2 hover:bg-white/20 rounded-full p-0.5"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                )}
                {(filters.amountMin || filters.amountMax) && (
                  <Badge variant="secondary" className="bg-yellow-600/30 text-yellow-200 border border-yellow-400/50">
                    Amount: {filters.amountMin || "0"} - {filters.amountMax || "∞"} MON
                    <button
                      onClick={() => {
                        updateFilters("amountMin", "")
                        updateFilters("amountMax", "")
                      }}
                      className="ml-2 hover:bg-white/20 rounded-full p-0.5"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                )}
              </div>
            </div>
          )}
        </CardContent>
      )}
    </Card>
  )
}
