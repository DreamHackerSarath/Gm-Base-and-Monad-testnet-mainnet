"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Info, Copy } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export function NetworkInfo() {
  const networkDetails = {
    name: "Monad Testnet",
    chainId: 10143,
    chainIdHex: "0x279f",
    currency: "MON",
    rpcUrl: "https://testnet-rpc.monad.xyz",
    explorerUrl: "https://testnet-explorer.monad.xyz",
    faucetUrl: "https://testnet.monad.xyz/",
  }

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: `${label} copied!`,
      description: "Copied to clipboard",
    })
  }

  const addToWallet = async () => {
    if (!window.ethereum) {
      toast({
        title: "Wallet not found",
        description: "Please install MetaMask or another Web3 wallet",
        variant: "destructive",
      })
      return
    }

    try {
      await window.ethereum.request({
        method: "wallet_addEthereumChain",
        params: [
          {
            chainId: networkDetails.chainIdHex,
            chainName: networkDetails.name,
            nativeCurrency: {
              name: networkDetails.currency,
              symbol: networkDetails.currency,
              decimals: 18,
            },
            rpcUrls: [networkDetails.rpcUrl],
            blockExplorerUrls: [networkDetails.explorerUrl],
          },
        ],
      })
      toast({
        title: "Network added!",
        description: "Monad Testnet has been added to your wallet",
      })
    } catch (error) {
      toast({
        title: "Failed to add network",
        description: "Please add the network manually",
        variant: "destructive",
      })
    }
  }

  return (
    <Card className="bg-white/10 backdrop-blur-sm border-white/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Info className="w-5 h-5 mr-2" />
          Monad Testnet Information
          <Badge variant="secondary" className="ml-2 bg-blue-600/50 text-white">
            Testnet
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-purple-200 text-sm">Network Name:</span>
              <div className="flex items-center space-x-2">
                <span className="text-white font-mono text-sm">{networkDetails.name}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(networkDetails.name, "Network name")}
                  className="p-1 h-auto"
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-purple-200 text-sm">Chain ID:</span>
              <div className="flex items-center space-x-2">
                <span className="text-white font-mono text-sm">{networkDetails.chainId}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(networkDetails.chainId.toString(), "Chain ID")}
                  className="p-1 h-auto"
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-purple-200 text-sm">Chain ID (Hex):</span>
              <div className="flex items-center space-x-2">
                <span className="text-white font-mono text-sm">{networkDetails.chainIdHex}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(networkDetails.chainIdHex, "Chain ID (Hex)")}
                  className="p-1 h-auto"
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-purple-200 text-sm">Currency:</span>
              <div className="flex items-center space-x-2">
                <span className="text-white font-mono text-sm">{networkDetails.currency}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(networkDetails.currency, "Currency symbol")}
                  className="p-1 h-auto"
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-purple-200 text-sm">RPC URL:</span>
              <div className="flex items-center space-x-2">
                <span className="text-white font-mono text-sm truncate max-w-32">{networkDetails.rpcUrl}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(networkDetails.rpcUrl, "RPC URL")}
                  className="p-1 h-auto"
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-purple-200 text-sm">Explorer:</span>
              <div className="flex items-center space-x-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => window.open(networkDetails.explorerUrl, "_blank")}
                  className="p-1 h-auto text-blue-300 hover:text-blue-200"
                >
                  <ExternalLink className="w-3 h-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(networkDetails.explorerUrl, "Explorer URL")}
                  className="p-1 h-auto"
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-purple-200 text-sm">Faucet:</span>
              <div className="flex items-center space-x-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => window.open(networkDetails.faucetUrl, "_blank")}
                  className="p-1 h-auto text-blue-300 hover:text-blue-200"
                >
                  <ExternalLink className="w-3 h-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(networkDetails.faucetUrl, "Faucet URL")}
                  className="p-1 h-auto"
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="flex space-x-3 pt-4">
          <Button onClick={addToWallet} className="flex-1 bg-purple-600 hover:bg-purple-700">
            Add to Wallet
          </Button>
          <Button
            variant="outline"
            onClick={() => window.open(networkDetails.faucetUrl, "_blank")}
            className="flex-1 bg-white/5 border-white/20 text-white hover:bg-white/10"
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Get Testnet MON
          </Button>
        </div>

        <div className="bg-blue-600/10 border border-blue-400/20 rounded-lg p-3">
          <p className="text-blue-200 text-sm">
            <strong>Note:</strong> This is the official Monad Testnet as listed on ChainList.org. Make sure to use these
            exact network parameters when connecting your wallet.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
