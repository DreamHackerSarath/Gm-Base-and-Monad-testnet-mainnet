"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useContract } from "@/hooks/use-contract"
import { useWeb3 } from "@/hooks/use-web3"
import { Loader2, Sun, AlertTriangle, CheckCircle } from "lucide-react"
import { toast } from "@/hooks/use-toast"

interface GMButtonProps {
  onGMSent: () => void
}

export function GMButton({ onGMSent }: GMButtonProps) {
  const [isLoading, setIsLoading] = useState(false)
  const { sendGM, canSendGM } = useContract()
  const { balance } = useWeb3()

  const hasEnoughBalance = balance && Number.parseFloat(balance) >= 1

  const handleGM = async () => {
    if (!hasEnoughBalance) {
      toast({
        title: "Insufficient balance",
        description: "You need at least 1 MON to send a GM. Get testnet tokens from the faucet.",
        variant: "destructive",
      })
      return
    }

    if (!canSendGM) {
      toast({
        title: "Already sent GM today",
        description: "You can only send one GM per day! Come back tomorrow.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const result = await sendGM()
      onGMSent()
      toast({
        title: "GM sent! ☀️",
        description: "Your daily GM has been recorded on the Monad blockchain",
      })
      console.log("GM transaction:", result)
    } catch (error: any) {
      console.error("GM Error:", error)
      toast({
        title: "Failed to send GM",
        description: error.message || "Please try again. Make sure you have enough MON and haven't sent a GM today.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="bg-white/10 backdrop-blur-sm border-white/20">
      <CardContent className="p-8 text-center">
        <div className="mb-6">
          <div className="flex items-center justify-center mb-4">
            <img src="/images/monad-logo.jpg" alt="Monad Logo" className="w-8 h-8 rounded-lg mr-2" />
            <Sun className="w-16 h-16 text-yellow-400" />
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">Good Morning!</h2>
          <p className="text-purple-200">Say gm to the Monad ecosystem for 1 MON</p>
        </div>

        {/* Status Messages */}
        {!hasEnoughBalance && (
          <div className="mb-4 p-3 bg-red-600/20 border border-red-400/50 rounded-lg">
            <div className="flex items-center justify-center text-red-200">
              <AlertTriangle className="w-4 h-4 mr-2" />
              <span className="text-sm">Insufficient MON balance. Get testnet tokens first.</span>
            </div>
          </div>
        )}

        {!canSendGM && hasEnoughBalance && (
          <div className="mb-4 p-3 bg-blue-600/20 border border-blue-400/50 rounded-lg">
            <div className="flex items-center justify-center text-blue-200">
              <CheckCircle className="w-4 h-4 mr-2" />
              <span className="text-sm">GM already sent today! Come back tomorrow.</span>
            </div>
          </div>
        )}

        <Button
          onClick={handleGM}
          disabled={isLoading || !canSendGM || !hasEnoughBalance}
          size="lg"
          className="bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-white font-bold py-4 px-8 text-xl disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Sending GM...
            </>
          ) : (
            "gm ☀️"
          )}
        </Button>

        <div className="mt-4 space-y-1">
          <p className="text-sm text-purple-300">Cost: 1 MON • Daily limit: 1 GM</p>
          <p className="text-xs text-purple-400">Powered by Monad • 10,000 TPS • Full EVM Compatibility</p>
          {balance && (
            <p className="text-xs text-purple-400">Your balance: {Number.parseFloat(balance).toFixed(4)} MON</p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
