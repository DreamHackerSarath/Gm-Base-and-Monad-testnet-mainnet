"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Copy, ExternalLink, CheckCircle, Clock, AlertCircle, Loader2 } from "lucide-react"
import { toast } from "@/hooks/use-toast"

interface Transaction {
  hash: string
  type: "gm" | "referral" | "claim" | "profile"
  status: "pending" | "confirmed" | "failed"
  timestamp: number
  blockNumber?: number
  gasUsed?: string
  gasPrice?: string
  value?: string
  from: string
  to: string
  confirmations?: number
  details?: {
    referrer?: string
    amount?: string
    profileData?: any
  }
}

interface TransactionModalProps {
  isOpen: boolean
  onClose: () => void
  transaction: Transaction | null
}

export function TransactionModal({ isOpen, onClose, transaction }: TransactionModalProps) {
  const [currentConfirmations, setCurrentConfirmations] = useState(0)
  const [isPolling, setIsPolling] = useState(false)

  useEffect(() => {
    if (transaction && transaction.status === "pending") {
      setIsPolling(true)
      const interval = setInterval(() => {
        // Simulate confirmation polling
        setCurrentConfirmations((prev) => {
          const newConfirmations = prev + 1
          if (newConfirmations >= 12) {
            setIsPolling(false)
            clearInterval(interval)
            // Update transaction status to confirmed
            if (transaction) {
              transaction.status = "confirmed"
              transaction.confirmations = newConfirmations
            }
          }
          return newConfirmations
        })
      }, 2000)

      return () => clearInterval(interval)
    }
  }, [transaction])

  if (!transaction) return null

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: `${label} copied!`,
      description: "Copied to clipboard",
    })
  }

  const openInExplorer = () => {
    window.open(`https://testnet-explorer.monad.xyz/tx/${transaction.hash}`, "_blank")
  }

  const getStatusIcon = () => {
    switch (transaction.status) {
      case "pending":
        return <Loader2 className="w-5 h-5 text-yellow-400 animate-spin" />
      case "confirmed":
        return <CheckCircle className="w-5 h-5 text-green-400" />
      case "failed":
        return <AlertCircle className="w-5 h-5 text-red-400" />
      default:
        return <Clock className="w-5 h-5 text-gray-400" />
    }
  }

  const getStatusColor = () => {
    switch (transaction.status) {
      case "pending":
        return "bg-yellow-600/20 text-yellow-200 border-yellow-400/50"
      case "confirmed":
        return "bg-green-600/20 text-green-200 border-green-400/50"
      case "failed":
        return "bg-red-600/20 text-red-200 border-red-400/50"
      default:
        return "bg-gray-600/20 text-gray-200 border-gray-400/50"
    }
  }

  const getTransactionTitle = () => {
    switch (transaction.type) {
      case "gm":
        return "Daily GM Transaction"
      case "referral":
        return "Referral GM Transaction"
      case "claim":
        return "Rewards Claim Transaction"
      case "profile":
        return "Profile Update Transaction"
      default:
        return "Transaction"
    }
  }

  const formatMON = (wei: string) => {
    const eth = Number.parseFloat(wei) / Math.pow(10, 18)
    return eth.toFixed(4)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-purple-900 border-purple-700 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-3">
            {getStatusIcon()}
            <span>{getTransactionTitle()}</span>
            <Badge variant="outline" className={getStatusColor()}>
              {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Transaction Hash */}
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-sm text-purple-300 mb-1">Transaction Hash</p>
                  <p className="font-mono text-sm text-white break-all">{transaction.hash}</p>
                </div>
                <div className="flex space-x-2 ml-4">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => copyToClipboard(transaction.hash, "Transaction hash")}
                    className="bg-white/5 border-white/20 text-white hover:bg-white/10"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={openInExplorer}
                    className="bg-white/5 border-white/20 text-white hover:bg-white/10"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Status and Confirmations */}
          {transaction.status === "pending" && (
            <Card className="bg-yellow-600/10 border-yellow-400/20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <Loader2 className="w-5 h-5 text-yellow-400 animate-spin" />
                  <div>
                    <p className="text-yellow-200 font-medium">Transaction Pending</p>
                    <p className="text-yellow-300 text-sm">
                      Confirmations: {currentConfirmations}/12 {isPolling && "(updating...)"}
                    </p>
                  </div>
                </div>
                <div className="mt-3">
                  <div className="w-full bg-yellow-900/30 rounded-full h-2">
                    <div
                      className="bg-yellow-400 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min((currentConfirmations / 12) * 100, 100)}%` }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {transaction.status === "confirmed" && (
            <Card className="bg-green-600/10 border-green-400/20">
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <div>
                    <p className="text-green-200 font-medium">Transaction Confirmed</p>
                    <p className="text-green-300 text-sm">
                      {transaction.confirmations || 12} confirmations • Block #{transaction.blockNumber || "N/A"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Transaction Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-4">
                <p className="text-purple-300 text-sm mb-2">From</p>
                <div className="flex items-center space-x-2">
                  <p className="font-mono text-sm text-white break-all">{transaction.from}</p>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyToClipboard(transaction.from, "From address")}
                    className="p-1 h-auto"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-4">
                <p className="text-purple-300 text-sm mb-2">To</p>
                <div className="flex items-center space-x-2">
                  <p className="font-mono text-sm text-white break-all">{transaction.to}</p>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyToClipboard(transaction.to, "To address")}
                    className="p-1 h-auto"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Value and Gas */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {transaction.value && (
              <Card className="bg-white/5 border-white/10">
                <CardContent className="p-4 text-center">
                  <p className="text-purple-300 text-sm mb-1">Value</p>
                  <p className="text-xl font-bold text-white">{formatMON(transaction.value)} MON</p>
                </CardContent>
              </Card>
            )}

            {transaction.gasUsed && (
              <Card className="bg-white/5 border-white/10">
                <CardContent className="p-4 text-center">
                  <p className="text-purple-300 text-sm mb-1">Gas Used</p>
                  <p className="text-lg font-semibold text-white">
                    {Number.parseInt(transaction.gasUsed).toLocaleString()}
                  </p>
                </CardContent>
              </Card>
            )}

            {transaction.gasPrice && (
              <Card className="bg-white/5 border-white/10">
                <CardContent className="p-4 text-center">
                  <p className="text-purple-300 text-sm mb-1">Gas Price</p>
                  <p className="text-lg font-semibold text-white">
                    {Number.parseFloat(transaction.gasPrice).toFixed(2)} Gwei
                  </p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Transaction Specific Details */}
          {transaction.details && (
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-4">
                <p className="text-purple-300 text-sm mb-3">Transaction Details</p>
                <div className="space-y-2">
                  {transaction.type === "referral" && transaction.details.referrer && (
                    <div className="flex justify-between">
                      <span className="text-purple-200">Referrer:</span>
                      <span className="font-mono text-sm text-white">{transaction.details.referrer}</span>
                    </div>
                  )}
                  {transaction.details.amount && (
                    <div className="flex justify-between">
                      <span className="text-purple-200">Amount:</span>
                      <span className="text-white">{transaction.details.amount} MON</span>
                    </div>
                  )}
                  {transaction.type === "gm" && (
                    <div className="flex justify-between">
                      <span className="text-purple-200">Action:</span>
                      <span className="text-white">Daily GM sent to Monad ecosystem</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Timestamp */}
          <Card className="bg-white/5 border-white/10">
            <CardContent className="p-4">
              <div className="flex justify-between items-center">
                <span className="text-purple-300">Timestamp:</span>
                <span className="text-white">{new Date(transaction.timestamp).toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>

          <Separator className="bg-white/10" />

          {/* Actions */}
          <div className="flex space-x-3">
            <Button onClick={openInExplorer} className="flex-1 bg-purple-600 hover:bg-purple-700">
              <ExternalLink className="w-4 h-4 mr-2" />
              View on Explorer
            </Button>
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1 bg-white/5 border-white/20 text-white hover:bg-white/10"
            >
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
