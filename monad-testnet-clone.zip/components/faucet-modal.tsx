"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useWeb3 } from "@/hooks/use-web3"
import { toast } from "@/hooks/use-toast"
import { ExternalLink, Copy, Droplets } from "lucide-react"

interface FaucetModalProps {
  isOpen: boolean
  onClose: () => void
}

export function FaucetModal({ isOpen, onClose }: FaucetModalProps) {
  const { account } = useWeb3()
  const [isLoading, setIsLoading] = useState(false)

  const copyAddress = () => {
    if (account) {
      navigator.clipboard.writeText(account)
      toast({
        title: "Address copied!",
        description: "Your wallet address has been copied to clipboard",
      })
    }
  }

  const openFaucet = () => {
    window.open("https://testnet.monad.xyz/", "_blank")
  }

  const addMonadTestnet = async () => {
    if (!window.ethereum) return

    try {
      await window.ethereum.request({
        method: "wallet_addEthereumChain",
        params: [
          {
            chainId: "0x279f", // 10143 in hex
            chainName: "Monad Testnet",
            nativeCurrency: {
              name: "MON",
              symbol: "MON",
              decimals: 18,
            },
            rpcUrls: ["https://testnet-rpc.monad.xyz"],
            blockExplorerUrls: ["https://testnet-explorer.monad.xyz"],
          },
        ],
      })
      toast({
        title: "Network added!",
        description: "Monad Testnet has been added to your wallet",
      })
    } catch (error) {
      toast({
        title: "Failed to add network",
        description: "Please add Monad Testnet manually",
        variant: "destructive",
      })
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-purple-900 border-purple-700 text-white max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Droplets className="w-5 h-5 mr-2 text-blue-400" />
            Get Testnet MON
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Step 1: Network */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-white">1. Add Monad Testnet</h3>
            <p className="text-purple-200 text-sm">First, make sure you have Monad Testnet added to your wallet.</p>
            <Button onClick={addMonadTestnet} className="w-full bg-purple-600 hover:bg-purple-700">
              Add Monad Testnet to Wallet
            </Button>
          </div>

          {/* Step 2: Address */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-white">2. Copy Your Address</h3>
            <div className="flex space-x-2">
              <Input value={account || ""} readOnly className="bg-white/5 border-white/20 text-white" />
              <Button
                onClick={copyAddress}
                variant="outline"
                size="sm"
                className="bg-white/5 border-white/20 text-white hover:bg-white/10"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Step 3: Faucet */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-white">3. Get Testnet Tokens</h3>
            <p className="text-purple-200 text-sm">
              Visit the official Monad testnet faucet to get free MON tokens for testing.
            </p>
            <Button onClick={openFaucet} className="w-full bg-blue-600 hover:bg-blue-700">
              <ExternalLink className="w-4 h-4 mr-2" />
              Open Monad Faucet
            </Button>
          </div>

          {/* Network Info */}
          <div className="bg-white/5 rounded-lg p-4 border border-white/10">
            <h4 className="font-semibold text-white mb-2">Network Details:</h4>
            <div className="space-y-1 text-sm text-purple-200">
              <p>
                <strong>Network:</strong> Monad Testnet
              </p>
              <p>
                <strong>Chain ID:</strong> 10143
              </p>
              <p>
                <strong>RPC:</strong> https://testnet-rpc.monad.xyz
              </p>
              <p>
                <strong>Explorer:</strong> https://testnet-explorer.monad.xyz
              </p>
            </div>
          </div>

          <Button
            onClick={onClose}
            variant="outline"
            className="w-full bg-white/5 border-white/20 text-white hover:bg-white/10"
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
