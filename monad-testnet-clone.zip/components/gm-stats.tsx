"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp } from "lucide-react"

export function GMStats() {
  const [stats, setStats] = useState({
    totalGMs: 0,
    totalFeesCollected: "0.00",
    totalReferrals: 0,
    averageDaily: 0,
  })

  useEffect(() => {
    // Simulate fetching stats - in production, this would come from contract events
    const interval = setInterval(() => {
      setStats({
        totalGMs: Math.floor(Math.random() * 1000) + 5000,
        totalFeesCollected: (Math.random() * 2000 + 3000).toFixed(2),
        totalReferrals: Math.floor(Math.random() * 500) + 1200,
        averageDaily: Math.floor(Math.random() * 50) + 150,
      })
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card className="bg-white/10 backdrop-blur-sm border-white/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
          GM Platform Statistics
          <Badge variant="secondary" className="ml-2 bg-purple-600/50 text-white">
            Live
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white/5 rounded-lg p-4 text-center border border-white/10">
            <div className="text-2xl font-bold text-white">{stats.totalGMs.toLocaleString()}</div>
            <div className="text-purple-200 text-sm">Total GMs</div>
          </div>

          <div className="bg-white/5 rounded-lg p-4 text-center border border-white/10">
            <div className="text-2xl font-bold text-green-400">{stats.totalFeesCollected}</div>
            <div className="text-purple-200 text-sm">MON Collected</div>
          </div>

          <div className="bg-white/5 rounded-lg p-4 text-center border border-white/10">
            <div className="text-2xl font-bold text-blue-400">{stats.totalReferrals.toLocaleString()}</div>
            <div className="text-purple-200 text-sm">Referrals</div>
          </div>

          <div className="bg-white/5 rounded-lg p-4 text-center border border-white/10">
            <div className="text-2xl font-bold text-yellow-400">{stats.averageDaily}</div>
            <div className="text-purple-200 text-sm">Daily Average</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
