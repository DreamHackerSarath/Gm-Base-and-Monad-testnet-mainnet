"use client"

import type React from "react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Coins, Palette, Gamepad2, TrendingUp, Shield, Zap, Users, Globe, Code } from "lucide-react"

interface EcosystemProject {
  name: string
  description: string
  category: string
  status: "live" | "coming-soon" | "beta"
  icon: React.ReactNode
  url?: string
  features: string[]
}

const ecosystemProjects: EcosystemProject[] = [
  {
    name: "MonadSwap",
    description: "High-performance DEX with 10,000 TPS trading",
    category: "DeFi",
    status: "live",
    icon: <Coins className="w-6 h-6" />,
    url: "#",
    features: ["AMM Trading", "Liquidity Pools", "Yield Farming", "Low Fees"],
  },
  {
    name: "MonadLend",
    description: "Lending and borrowing protocol",
    category: "DeFi",
    status: "beta",
    icon: <TrendingUp className="w-6 h-6" />,
    url: "#",
    features: ["Lending", "Borrowing", "Collateral", "Interest Rates"],
  },
  {
    name: "MonadNFT",
    description: "Fast NFT marketplace and minting platform",
    category: "NFT",
    status: "live",
    icon: <Palette className="w-6 h-6" />,
    url: "#",
    features: ["NFT Trading", "Minting", "Collections", "Royalties"],
  },
  {
    name: "MonadGames",
    description: "GameFi platform with instant transactions",
    category: "Gaming",
    status: "coming-soon",
    icon: <Gamepad2 className="w-6 h-6" />,
    features: ["Play-to-Earn", "NFT Items", "Tournaments", "Rewards"],
  },
  {
    name: "MonadBridge",
    description: "Cross-chain bridge for asset transfers",
    category: "Infrastructure",
    status: "beta",
    icon: <Globe className="w-6 h-6" />,
    url: "#",
    features: ["Cross-chain", "Asset Bridge", "Multi-chain", "Security"],
  },
  {
    name: "MonadTools",
    description: "Developer tools and analytics",
    category: "Developer",
    status: "live",
    icon: <Code className="w-6 h-6" />,
    url: "#",
    features: ["Analytics", "APIs", "SDKs", "Documentation"],
  },
]

export function EcosystemIntegration() {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "live":
        return "bg-green-600/20 text-green-200 border-green-400/50"
      case "beta":
        return "bg-yellow-600/20 text-yellow-200 border-yellow-400/50"
      case "coming-soon":
        return "bg-blue-600/20 text-blue-200 border-blue-400/50"
      default:
        return "bg-gray-600/20 text-gray-200 border-gray-400/50"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "live":
        return "Live"
      case "beta":
        return "Beta"
      case "coming-soon":
        return "Coming Soon"
      default:
        return "Unknown"
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-4">Monad Ecosystem</h2>
        <p className="text-purple-200 max-w-2xl mx-auto">
          Explore the growing ecosystem of DeFi, NFT, Gaming, and Infrastructure projects built on Monad's
          high-performance EVM-compatible blockchain.
        </p>
      </div>

      {/* Ecosystem Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-white">12+</div>
            <div className="text-purple-200 text-sm">Projects</div>
          </CardContent>
        </Card>
        <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-white">$50M+</div>
            <div className="text-purple-200 text-sm">TVL</div>
          </CardContent>
        </Card>
        <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-white">100K+</div>
            <div className="text-purple-200 text-sm">Users</div>
          </CardContent>
        </Card>
        <Card className="bg-white/10 backdrop-blur-sm border-white/20 text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-white">10,000</div>
            <div className="text-purple-200 text-sm">TPS</div>
          </CardContent>
        </Card>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {ecosystemProjects.map((project, index) => (
          <Card
            key={index}
            className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/15 transition-colors"
          >
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-purple-600/20 rounded-lg text-purple-200">{project.icon}</div>
                  <div>
                    <CardTitle className="text-white text-lg">{project.name}</CardTitle>
                    <Badge variant="outline" className="text-xs mt-1 text-purple-300 border-purple-400/50">
                      {project.category}
                    </Badge>
                  </div>
                </div>
                <Badge variant="outline" className={`text-xs ${getStatusColor(project.status)}`}>
                  {getStatusText(project.status)}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-purple-200 text-sm">{project.description}</p>

              <div className="space-y-2">
                <h4 className="text-white font-medium text-sm">Features:</h4>
                <div className="flex flex-wrap gap-1">
                  {project.features.map((feature, idx) => (
                    <Badge key={idx} variant="secondary" className="bg-white/5 text-purple-200 text-xs">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex space-x-2">
                {project.status === "live" && project.url && (
                  <Button
                    size="sm"
                    className="flex-1 bg-purple-600 hover:bg-purple-700"
                    onClick={() => window.open(project.url, "_blank")}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Launch App
                  </Button>
                )}
                {project.status === "beta" && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 bg-yellow-600/20 border-yellow-400/50 text-yellow-200 hover:bg-yellow-600/30"
                  >
                    Try Beta
                  </Button>
                )}
                {project.status === "coming-soon" && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 bg-blue-600/20 border-blue-400/50 text-blue-200"
                    disabled
                  >
                    Coming Soon
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Integration Benefits */}
      <Card className="bg-white/5 backdrop-blur-sm border-white/10">
        <CardHeader>
          <CardTitle className="text-white text-xl text-center">Why Build on Monad?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <h3 className="text-white font-semibold mb-2">10,000 TPS</h3>
              <p className="text-purple-200 text-sm">Ultra-high throughput for seamless user experiences</p>
            </div>
            <div className="text-center">
              <Shield className="w-8 h-8 text-green-400 mx-auto mb-3" />
              <h3 className="text-white font-semibold mb-2">EVM Compatible</h3>
              <p className="text-purple-200 text-sm">Deploy existing Ethereum contracts without changes</p>
            </div>
            <div className="text-center">
              <Users className="w-8 h-8 text-blue-400 mx-auto mb-3" />
              <h3 className="text-white font-semibold mb-2">Growing Ecosystem</h3>
              <p className="text-purple-200 text-sm">Join a thriving community of builders and users</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Developer Resources */}
      <Card className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 backdrop-blur-sm border-white/20">
        <CardContent className="p-6 text-center">
          <h3 className="text-xl font-bold text-white mb-4">Build on Monad</h3>
          <p className="text-purple-200 mb-6">
            Ready to build the next generation of dApps? Get started with Monad's developer resources.
          </p>
          <div className="flex justify-center space-x-4">
            <Button
              onClick={() => window.open("https://developers.monad.xyz/", "_blank")}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Code className="w-4 h-4 mr-2" />
              Developer Docs
            </Button>
            <Button
              variant="outline"
              onClick={() => window.open("https://testnet.monad.xyz/", "_blank")}
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Get Testnet Tokens
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
