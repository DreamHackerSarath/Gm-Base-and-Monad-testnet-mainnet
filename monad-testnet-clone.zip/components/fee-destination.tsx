"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ExternalLink, Copy, Wallet, DollarSign } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export function FeeDestination() {
  const ownerWallet = "0xF0d52c2Ff5f4779a0D10D81824b2F7EB40c2EDb9"

  const copyAddress = () => {
    navigator.clipboard.writeText(ownerWallet)
    toast({
      title: "Address copied!",
      description: "Owner wallet address has been copied to clipboard",
    })
  }

  const openInExplorer = () => {
    window.open(`https://testnet-explorer.monad.xyz/address/${ownerWallet}`, "_blank")
  }

  return (
    <Card className="bg-white/10 backdrop-blur-sm border-white/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <DollarSign className="w-5 h-5 mr-2 text-green-400" />
          GM Fee Destination
          <Badge variant="secondary" className="ml-2 bg-green-600/50 text-white">
            Active
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-green-600/10 border border-green-400/20 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <Wallet className="w-4 h-4 text-green-400" />
              <span className="text-green-200 font-medium">Owner Wallet</span>
            </div>
            <Badge variant="outline" className="bg-green-600/20 text-green-200 border-green-400/50">
              Monad Testnet
            </Badge>
          </div>

          <div className="bg-black/20 rounded-lg p-3 mb-3">
            <p className="font-mono text-sm text-white break-all">{ownerWallet}</p>
          </div>

          <div className="flex space-x-2">
            <Button
              size="sm"
              onClick={copyAddress}
              className="flex-1 bg-green-600/20 border border-green-400/50 text-green-200 hover:bg-green-600/30"
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy Address
            </Button>
            <Button
              size="sm"
              onClick={openInExplorer}
              className="flex-1 bg-blue-600/20 border border-blue-400/50 text-blue-200 hover:bg-blue-600/30"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              View on Explorer
            </Button>
          </div>
        </div>

        <div className="space-y-3">
          <h4 className="text-white font-medium">Fee Structure:</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="bg-white/5 rounded-lg p-3 border border-white/10">
              <div className="flex items-center justify-between">
                <span className="text-purple-200 text-sm">Daily GM Fee:</span>
                <span className="text-white font-semibold">1.0 MON</span>
              </div>
              <p className="text-purple-300 text-xs mt-1">100% to owner wallet</p>
            </div>

            <div className="bg-white/5 rounded-lg p-3 border border-white/10">
              <div className="flex items-center justify-between">
                <span className="text-purple-200 text-sm">Referral GM Fee:</span>
                <span className="text-white font-semibold">0.5 MON</span>
              </div>
              <p className="text-purple-300 text-xs mt-1">0.25 to owner, 0.25 to referrer</p>
            </div>
          </div>
        </div>

        <div className="bg-blue-600/10 border border-blue-400/20 rounded-lg p-3">
          <p className="text-blue-200 text-sm">
            <strong>Note:</strong> All GM fees are automatically sent to this wallet address on the Monad Testnet. The
            smart contract handles fee distribution transparently and immutably.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
