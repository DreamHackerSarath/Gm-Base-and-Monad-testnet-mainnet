"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Repeat, PiggyBank } from "lucide-react"

export function DeFiIntegration() {
  const defiProtocols = [
    {
      name: "MonadSwap",
      type: "DEX",
      tvl: "$25.5M",
      apy: "12.5%",
      icon: <Repeat className="w-6 h-6" />,
      description: "High-speed AMM with minimal slippage",
    },
    {
      name: "MonadLend",
      type: "Lending",
      tvl: "$18.2M",
      apy: "8.3%",
      icon: <PiggyBank className="w-6 h-6" />,
      description: "Lending and borrowing protocol",
    },
    {
      name: "MonadYield",
      type: "Yield Farming",
      tvl: "$12.8M",
      apy: "24.7%",
      icon: <TrendingUp className="w-6 h-6" />,
      description: "Automated yield optimization",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-white mb-4">DeFi on Monad</h2>
        <p className="text-purple-200">Access high-performance DeFi protocols with instant transactions</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {defiProtocols.map((protocol, index) => (
          <Card key={index} className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-green-600/20 rounded-lg text-green-200">{protocol.icon}</div>
                <div>
                  <CardTitle className="text-white">{protocol.name}</CardTitle>
                  <Badge variant="outline" className="text-xs text-green-300 border-green-400/50">
                    {protocol.type}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-purple-200 text-sm">{protocol.description}</p>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-purple-300">TVL</p>
                  <p className="text-lg font-bold text-white">{protocol.tvl}</p>
                </div>
                <div>
                  <p className="text-xs text-purple-300">APY</p>
                  <p className="text-lg font-bold text-green-400">{protocol.apy}</p>
                </div>
              </div>

              <Button className="w-full bg-green-600 hover:bg-green-700">Connect & Trade</Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
