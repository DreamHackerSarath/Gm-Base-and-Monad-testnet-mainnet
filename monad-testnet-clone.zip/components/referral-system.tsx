"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useContract } from "@/hooks/use-contract"
import { Copy, Users, Gift } from "lucide-react"
import { toast } from "@/hooks/use-toast"

interface ReferralSystemProps {
  pendingRewards: string
  onRewardsClaimed: () => void
  onReferralSent?: (referrer: string) => void
}

export function ReferralSystem({ pendingRewards, onRewardsClaimed, onReferralSent }: ReferralSystemProps) {
  const [referrerAddress, setReferrerAddress] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { sendReferralGM, claimRewards, canClaimRewards } = useContract()

  const handleReferralGM = async () => {
    if (!referrerAddress) {
      toast({
        title: "Enter referrer address",
        description: "Please enter a valid referrer address",
        variant: "destructive",
      })
      return
    }

    if (!referrerAddress.match(/^0x[a-fA-F0-9]{40}$/)) {
      toast({
        title: "Invalid address",
        description: "Please enter a valid Ethereum address",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      await sendReferralGM(referrerAddress)

      // Notify parent component about the referral
      if (onReferralSent) {
        onReferralSent(referrerAddress)
      }

      toast({
        title: "Referral GM sent! 🎉",
        description: "Your referrer will receive 0.25 MON",
      })
      setReferrerAddress("")
    } catch (error: any) {
      toast({
        title: "Failed to send referral GM",
        description: error.message || "Please try again",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleClaimRewards = async () => {
    if (!canClaimRewards) {
      toast({
        title: "Cannot claim yet",
        description: "You can only claim rewards once every 60 days",
        variant: "destructive",
      })
      return
    }

    if (Number.parseFloat(pendingRewards) === 0) {
      toast({
        title: "No rewards to claim",
        description: "You don't have any pending rewards",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      await claimRewards()
      onRewardsClaimed()
      toast({
        title: "Rewards claimed! 💰",
        description: "Your referral rewards have been transferred",
      })
    } catch (error: any) {
      toast({
        title: "Failed to claim rewards",
        description: error.message || "Please try again",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const copyReferralLink = () => {
    if (typeof window !== "undefined") {
      const referralLink = `${window.location.origin}?ref=${window.ethereum?.selectedAddress || "your-address"}`
      navigator.clipboard.writeText(referralLink)
      toast({
        title: "Referral link copied!",
        description: "Share this link to earn 0.25 MON per referral",
      })
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {/* Referral GM */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Users className="w-5 h-5 mr-2 text-green-400" />
            Referral GM
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="referrer" className="text-purple-200">
              Referrer Address
            </Label>
            <Input
              id="referrer"
              value={referrerAddress}
              onChange={(e) => setReferrerAddress(e.target.value)}
              placeholder="0x..."
              className="bg-white/5 border-white/20 text-white placeholder:text-purple-300"
            />
          </div>
          <Button
            onClick={handleReferralGM}
            disabled={isLoading || !referrerAddress}
            className="w-full bg-green-600 hover:bg-green-700 disabled:opacity-50"
          >
            {isLoading ? "Sending..." : "Send Referral GM (0.5 MON)"}
          </Button>
          <Button
            onClick={copyReferralLink}
            variant="outline"
            className="w-full bg-white/5 border-white/20 text-white hover:bg-white/10"
          >
            <Copy className="w-4 h-4 mr-2" />
            Copy Referral Link
          </Button>
          <p className="text-xs text-purple-300">
            When someone uses your referral, you get 0.25 MON and the platform gets 0.25 MON
          </p>
        </CardContent>
      </Card>

      {/* Rewards */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Gift className="w-5 h-5 mr-2 text-yellow-400" />
            Rewards
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <p className="text-2xl font-bold text-white">{pendingRewards} MON</p>
            <p className="text-purple-200 text-sm">Pending Rewards</p>
          </div>
          <Button
            onClick={handleClaimRewards}
            disabled={isLoading || !canClaimRewards || Number.parseFloat(pendingRewards) === 0}
            className="w-full bg-yellow-600 hover:bg-yellow-700 disabled:opacity-50"
          >
            {isLoading ? "Claiming..." : "Claim Rewards"}
          </Button>
          <div className="space-y-1 text-xs text-purple-300">
            <p>• Rewards can be claimed once every 60 days</p>
            <p>• Minimum claim amount: 0.1 MON</p>
            <p>• Referral rewards are stored securely on-chain</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
