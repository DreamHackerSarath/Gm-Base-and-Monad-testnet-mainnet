"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Trophy, Medal, Award } from "lucide-react"

interface LeaderboardEntry {
  address: string
  gmCount: number
  streak: number
  rank: number
}

export function Leaderboard() {
  const [leaders, setLeaders] = useState<LeaderboardEntry[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Mock data - replace with actual contract calls
    const mockData: LeaderboardEntry[] = [
      { address: "0x1234...5678", gmCount: 45, streak: 12, rank: 1 },
      { address: "0x2345...6789", gmCount: 38, streak: 8, rank: 2 },
      { address: "0x3456...7890", gmCount: 32, streak: 15, rank: 3 },
      { address: "0x4567...8901", gmCount: 28, streak: 6, rank: 4 },
      { address: "0x5678...9012", gmCount: 25, streak: 9, rank: 5 },
    ]

    setTimeout(() => {
      setLeaders(mockData)
      setLoading(false)
    }, 1000)
  }, [])

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-5 h-5 text-yellow-500" />
      case 2:
        return <Medal className="w-5 h-5 text-gray-400" />
      case 3:
        return <Award className="w-5 h-5 text-orange-600" />
      default:
        return (
          <span className="w-5 h-5 flex items-center justify-center text-sm font-bold text-purple-300">#{rank}</span>
        )
    }
  }

  return (
    <Card className="bg-white/10 backdrop-blur-sm border-white/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Trophy className="w-5 h-5 mr-2 text-yellow-400" />
          Leaderboard
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {loading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-12 bg-white/5 rounded-lg"></div>
              </div>
            ))}
          </div>
        ) : (
          leaders.map((leader) => (
            <div
              key={leader.address}
              className="flex items-center justify-between p-3 bg-white/5 rounded-lg hover:bg-white/10 transition-colors"
            >
              <div className="flex items-center space-x-3">
                {getRankIcon(leader.rank)}
                <div>
                  <p className="text-white font-medium">
                    {leader.address.slice(0, 6)}...{leader.address.slice(-4)}
                  </p>
                  <p className="text-purple-300 text-sm">
                    {leader.gmCount} GMs • {leader.streak} streak
                  </p>
                </div>
              </div>
              <Badge variant="secondary" className="bg-purple-600/50 text-white">
                {leader.gmCount}
              </Badge>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  )
}
