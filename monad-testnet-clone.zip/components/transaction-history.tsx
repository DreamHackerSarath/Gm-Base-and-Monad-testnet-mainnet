"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TransactionModal } from "./transaction-modal"
import { History, ExternalLink, CheckCircle, Clock, AlertCircle, Loader2 } from "lucide-react"
import { TransactionFiltersComponent, type TransactionFilters } from "./transaction-filters"
import { Button } from "@/components/ui/button"

interface Transaction {
  hash: string
  type: "gm" | "referral" | "claim" | "profile"
  status: "pending" | "confirmed" | "failed"
  timestamp: number
  blockNumber?: number
  gasUsed?: string
  gasPrice?: string
  value?: string
  from: string
  to: string
  confirmations?: number
  details?: {
    referrer?: string
    amount?: string
    profileData?: any
  }
}

interface TransactionHistoryProps {
  userAddress?: string
}

export function TransactionHistory({ userAddress }: TransactionHistoryProps) {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null)
  const [showModal, setShowModal] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  const [filters, setFilters] = useState<TransactionFilters>({
    type: [],
    status: [],
    dateFrom: "",
    dateTo: "",
    amountMin: "",
    amountMax: "",
  })

  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([])

  useEffect(() => {
    if (userAddress) {
      loadTransactionHistory()
    }
  }, [userAddress])

  const loadTransactionHistory = async () => {
    setIsLoading(true)

    // Simulate loading transaction history
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Mock transaction data
    const mockTransactions: Transaction[] = [
      {
        hash: "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
        type: "gm",
        status: "confirmed",
        timestamp: Date.now() - 3600000, // 1 hour ago
        blockNumber: 1234567,
        gasUsed: "21000",
        gasPrice: "2.5",
        value: "1000000000000000000", // 1 MON in wei
        from: userAddress || "0x...",
        to: "0xF0d52c2Ff5f4779a0D10D81824b2F7EB40c2EDb9",
        confirmations: 25,
        details: {
          amount: "1.0",
        },
      },
      {
        hash: "0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890",
        type: "referral",
        status: "confirmed",
        timestamp: Date.now() - 7200000, // 2 hours ago
        blockNumber: 1234550,
        gasUsed: "35000",
        gasPrice: "2.2",
        value: "500000000000000000", // 0.5 MON in wei
        from: userAddress || "0x...",
        to: "0xF0d52c2Ff5f4779a0D10D81824b2F7EB40c2EDb9",
        confirmations: 45,
        details: {
          referrer: "0x9876543210987654321098765432109876543210",
          amount: "0.5",
        },
      },
      {
        hash: "0x9876543210987654321098765432109876543210987654321098765432109876",
        type: "claim",
        status: "pending",
        timestamp: Date.now() - 300000, // 5 minutes ago
        gasUsed: "45000",
        gasPrice: "2.8",
        value: "2500000000000000000", // 2.5 MON in wei
        from: "0xF0d52c2Ff5f4779a0D10D81824b2F7EB40c2EDb9",
        to: userAddress || "0x...",
        confirmations: 3,
        details: {
          amount: "2.5",
        },
      },
    ]

    setTransactions(mockTransactions)
    setIsLoading(false)
  }

  const applyFilters = (transactions: Transaction[]) => {
    let filtered = transactions

    // Filter by type
    if (filters.type.length > 0) {
      filtered = filtered.filter((tx) => filters.type.includes(tx.type))
    }

    // Filter by status
    if (filters.status.length > 0) {
      filtered = filtered.filter((tx) => filters.status.includes(tx.status))
    }

    // Filter by date range
    if (filters.dateFrom) {
      const fromDate = new Date(filters.dateFrom)
      filtered = filtered.filter((tx) => new Date(tx.timestamp) >= fromDate)
    }

    if (filters.dateTo) {
      const toDate = new Date(filters.dateTo)
      toDate.setHours(23, 59, 59, 999) // End of day
      filtered = filtered.filter((tx) => new Date(tx.timestamp) <= toDate)
    }

    // Filter by amount range
    if (filters.amountMin && filters.amountMin !== "") {
      const minAmount = Number.parseFloat(filters.amountMin) * Math.pow(10, 18) // Convert to wei
      filtered = filtered.filter((tx) => {
        if (!tx.value) return false
        return Number.parseFloat(tx.value) >= minAmount
      })
    }

    if (filters.amountMax && filters.amountMax !== "") {
      const maxAmount = Number.parseFloat(filters.amountMax) * Math.pow(10, 18) // Convert to wei
      filtered = filtered.filter((tx) => {
        if (!tx.value) return true
        return Number.parseFloat(tx.value) <= maxAmount
      })
    }

    return filtered
  }

  const getTransactionCounts = () => {
    const byType = transactions.reduce(
      (acc, tx) => {
        acc[tx.type] = (acc[tx.type] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    )

    const byStatus = transactions.reduce(
      (acc, tx) => {
        acc[tx.status] = (acc[tx.status] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    )

    return {
      total: transactions.length,
      filtered: filteredTransactions.length,
      byType,
      byStatus,
    }
  }

  const handleFiltersChange = (newFilters: TransactionFilters) => {
    setFilters(newFilters)
  }

  const handleClearFilters = () => {
    setFilters({
      type: [],
      status: [],
      dateFrom: "",
      dateTo: "",
      amountMin: "",
      amountMax: "",
    })
  }

  useEffect(() => {
    const filtered = applyFilters(transactions)
    setFilteredTransactions(filtered)
  }, [transactions, filters])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Loader2 className="w-4 h-4 text-yellow-400 animate-spin" />
      case "confirmed":
        return <CheckCircle className="w-4 h-4 text-green-400" />
      case "failed":
        return <AlertCircle className="w-4 h-4 text-red-400" />
      default:
        return <Clock className="w-4 h-4 text-gray-400" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-600/20 text-yellow-200 border-yellow-400/50"
      case "confirmed":
        return "bg-green-600/20 text-green-200 border-green-400/50"
      case "failed":
        return "bg-red-600/20 text-red-200 border-red-400/50"
      default:
        return "bg-gray-600/20 text-gray-200 border-gray-400/50"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "gm":
        return "☀️"
      case "referral":
        return "👥"
      case "claim":
        return "💰"
      case "profile":
        return "👤"
      default:
        return "📄"
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "gm":
        return "Daily GM"
      case "referral":
        return "Referral GM"
      case "claim":
        return "Claim Rewards"
      case "profile":
        return "Update Profile"
      default:
        return "Transaction"
    }
  }

  const formatMON = (wei: string) => {
    const eth = Number.parseFloat(wei) / Math.pow(10, 18)
    return eth.toFixed(4)
  }

  const openTransactionDetails = (transaction: Transaction) => {
    setSelectedTransaction(transaction)
    setShowModal(true)
  }

  if (!userAddress) {
    return (
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardContent className="p-8 text-center">
          <History className="w-12 h-12 text-purple-300 mx-auto mb-4" />
          <p className="text-purple-200">Connect your wallet to view transaction history</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <>
      <div className="space-y-6">
        {/* Transaction Filters */}
        <TransactionFiltersComponent
          filters={filters}
          onFiltersChange={handleFiltersChange}
          onClearFilters={handleClearFilters}
          transactionCounts={getTransactionCounts()}
        />

        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <History className="w-5 h-5 mr-2" />
              Transaction History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="h-16 bg-white/5 rounded-lg"></div>
                  </div>
                ))}
              </div>
            ) : filteredTransactions.length === 0 ? (
              <div className="text-center py-8">
                {transactions.length === 0 ? (
                  <>
                    <p className="text-purple-200">No transactions found</p>
                    <p className="text-purple-300 text-sm mt-2">Your transaction history will appear here</p>
                  </>
                ) : (
                  <>
                    <p className="text-purple-200">No transactions match your filters</p>
                    <p className="text-purple-300 text-sm mt-2">Try adjusting your filter criteria</p>
                    <Button
                      onClick={handleClearFilters}
                      variant="outline"
                      className="mt-4 bg-white/5 border-white/20 text-white hover:bg-white/10"
                    >
                      Clear Filters
                    </Button>
                  </>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredTransactions.map((tx) => (
                  <div
                    key={tx.hash}
                    className="flex items-center justify-between p-4 bg-white/5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
                    onClick={() => openTransactionDetails(tx)}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="text-2xl">{getTypeIcon(tx.type)}</div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <p className="text-white font-medium">{getTypeLabel(tx.type)}</p>
                          <Badge variant="outline" className={`text-xs ${getStatusColor(tx.status)}`}>
                            {getStatusIcon(tx.status)}
                            <span className="ml-1">{tx.status}</span>
                          </Badge>
                        </div>
                        <p className="text-purple-300 text-sm">{new Date(tx.timestamp).toLocaleString()}</p>
                        <p className="text-purple-400 text-xs font-mono">
                          {tx.hash.slice(0, 10)}...{tx.hash.slice(-8)}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      {tx.value && (
                        <p className="text-white font-semibold">
                          {tx.type === "claim" ? "+" : "-"}
                          {formatMON(tx.value)} MON
                        </p>
                      )}
                      <div className="flex items-center space-x-2 mt-1">
                        <ExternalLink className="w-3 h-3 text-purple-400" />
                        <span className="text-purple-400 text-xs">View Details</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <TransactionModal isOpen={showModal} onClose={() => setShowModal(false)} transaction={selectedTransaction} />
    </>
  )
}
