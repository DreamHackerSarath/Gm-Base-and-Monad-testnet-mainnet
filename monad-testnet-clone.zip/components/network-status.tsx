"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Wifi, WifiOff } from "lucide-react"

export function NetworkStatus() {
  const [isConnected, setIsConnected] = useState(false)
  const [networkName, setNetworkName] = useState("")
  const [chainId, setChainId] = useState("")

  useEffect(() => {
    checkNetwork()

    if (window.ethereum) {
      window.ethereum.on("chainChanged", checkNetwork)
    }

    return () => {
      if (window.ethereum) {
        window.ethereum.removeListener("chainChanged", checkNetwork)
      }
    }
  }, [])

  const checkNetwork = async () => {
    if (!window.ethereum) return

    try {
      const chainId = await window.ethereum.request({ method: "eth_chainId" })
      const chainIdDecimal = Number.parseInt(chainId, 16)

      if (chainIdDecimal === 10143) {
        setIsConnected(true)
        setNetworkName("Monad Testnet")
        setChainId("10143")
      } else {
        setIsConnected(false)
        setNetworkName("Wrong Network")
        setChainId(chainIdDecimal.toString())
      }
    } catch (error) {
      setIsConnected(false)
      setNetworkName("Disconnected")
    }
  }

  return (
    <Badge
      variant={isConnected ? "default" : "destructive"}
      className={`${
        isConnected
          ? "bg-green-600/20 border-green-400/50 text-green-200"
          : "bg-red-600/20 border-red-400/50 text-red-200"
      }`}
    >
      {isConnected ? <Wifi className="w-3 h-3 mr-1" /> : <WifiOff className="w-3 h-3 mr-1" />}
      {networkName}
    </Badge>
  )
}
