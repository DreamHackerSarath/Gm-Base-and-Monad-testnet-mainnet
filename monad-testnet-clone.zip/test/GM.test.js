const { expect } = require("chai")
const { ethers } = require("hardhat")
const { time } = require("@nomicfoundation/hardhat-network-helpers")

const OWNER_WALLET = "0xF0d52c2Ff5f4779a0D10D81824b2F7EB40c2EDb9"

describe("GM Contract", () => {
  let GM, gm, owner, addr1, addr2
  const GM_FEE = ethers.parseEther("1") // 1 MONAD
  const REFERRAL_GM_FEE = ethers.parseEther("0.5") // 0.5 MONAD

  beforeEach(async () => {
    ;[owner, addr1, addr2] = await ethers.getSigners()
    GM = await ethers.getContractFactory("GM")
    gm = await GM.deploy()
    await gm.waitForDeployment()
  })

  describe("Owner Wallet", () => {
    it("Should have correct owner wallet address", async () => {
      expect(await gm.OWNER_WALLET()).to.equal(OWNER_WALLET)
    })
  })

  describe("GM Function", () => {
    it("Should accept correct GM fee", async () => {
      await expect(gm.connect(addr1).gm({ value: GM_FEE }))
        .to.emit(gm, "GMSent")
        .withArgs(addr1.address, await time.latest())
    })

    it("Should reject incorrect GM fee", async () => {
      await expect(gm.connect(addr1).gm({ value: ethers.parseEther("0.5") })).to.be.revertedWith(
        "GM: Incorrect fee amount",
      )
    })

    it("Should prevent multiple GMs in same day", async () => {
      await gm.connect(addr1).gm({ value: GM_FEE })
      await expect(gm.connect(addr1).gm({ value: GM_FEE })).to.be.revertedWith("GM: Already sent GM today")
    })

    it("Should increment GM count", async () => {
      await gm.connect(addr1).gm({ value: GM_FEE })
      expect(await gm.gmCount()).to.equal(1)
    })
  })

  describe("Referral GM Function", () => {
    it("Should accept correct referral fee", async () => {
      await expect(gm.connect(addr1).referGM(addr2.address, { value: REFERRAL_GM_FEE }))
        .to.emit(gm, "GMReferred")
        .withArgs(addr1.address, addr2.address, await time.latest())
    })

    it("Should reject self-referral", async () => {
      await expect(gm.connect(addr1).referGM(addr1.address, { value: REFERRAL_GM_FEE })).to.be.revertedWith(
        "GM: Cannot refer yourself",
      )
    })

    it("Should accumulate referral rewards", async () => {
      await gm.connect(addr1).referGM(addr2.address, { value: REFERRAL_GM_FEE })
      const expectedReward = REFERRAL_GM_FEE / 2n
      expect(await gm.referralRewards(addr2.address)).to.equal(expectedReward)
    })
  })

  describe("Profile Management", () => {
    it("Should set user profile", async () => {
      const profileData = ["@testuser", "testuser#1234", "@testuser_tg", addr1.address, "SolanaAddressHere123"]

      await expect(gm.connect(addr1).setProfile(...profileData))
        .to.emit(gm, "ProfileUpdated")
        .withArgs(addr1.address, ...profileData)

      const profile = await gm.profiles(addr1.address)
      expect(profile.xUsername).to.equal("@testuser")
      expect(profile.discordUsername).to.equal("testuser#1234")
    })
  })

  describe("Rewards Claiming", () => {
    it("Should allow claiming after cooldown", async () => {
      // Add some rewards
      await gm.connect(addr1).referGM(addr2.address, { value: REFERRAL_GM_FEE })

      // Fast forward time (in real test, you'd use time helpers)
      await time.increase(60 * 24 * 60 * 60) // 60 days

      // Check if rewards can be claimed
      expect(await gm.referralRewards(addr2.address)).to.be.gt(0)
    })
  })
})
