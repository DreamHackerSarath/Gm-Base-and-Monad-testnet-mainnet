const { ethers } = require("hardhat")

async function main() {
  console.log("Deploying GM contract to Monad Testnet...")

  // Get the ContractFactory and Signers
  const [deployer] = await ethers.getSigners()
  console.log("Deploying contracts with the account:", deployer.address)

  // Get account balance
  const balance = await deployer.provider.getBalance(deployer.address)
  console.log("Account balance:", ethers.formatEther(balance), "MONAD")

  // Deploy the contract
  const GM = await ethers.getContractFactory("GM")
  const gm = await GM.deploy()

  await gm.waitForDeployment()
  const contractAddress = await gm.getAddress()

  console.log("GM contract deployed to:", contractAddress)
  console.log("Owner wallet:", "0xF0d52c2Ff5f4779a0D10D81824b2F7EB40c2EDb9")

  // Verify deployment
  console.log("\nVerifying deployment...")
  const totalGMs = await gm.gmCount()
  console.log("Initial GM count:", totalGMs.toString())

  // Save deployment info
  const deploymentInfo = {
    contractAddress: contractAddress,
    network: "monadTestnet",
    deployer: deployer.address,
    deploymentTime: new Date().toISOString(),
    abi: GM.interface.formatJson(),
  }

  console.log("\nDeployment Info:")
  console.log(JSON.stringify(deploymentInfo, null, 2))

  // Instructions
  console.log("\n=== DEPLOYMENT COMPLETE ===")
  console.log("1. Update CONTRACT_ADDRESS in hooks/use-contract.ts")
  console.log("2. Add contract address to your frontend")
  console.log("3. Fund the deployer account with MONAD for testing")
  console.log("4. Test the contract functions")
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error)
    process.exit(1)
  })
