"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Sun, Flame, Trophy, Users, Coins, Share2, Copy, Gift, ExternalLink, User, Zap, Shield } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { WalletConnect } from "@/components/wallet-connect"
import { NetworkSwitch } from "@/components/network-switch"
import { MarketWidget } from "@/components/market-widget"
import {
  useGMContract,
  useUserStats,
  useLeaderboard,
  useUserProfile,
  GM_FEE,
  REFERRAL_REWARD,
} from "@/hooks/use-gm-contract"
import { useWallet } from "@/hooks/use-wallet"
import { baseMainnet, formatAddress } from "@/lib/wallet-utils"
import { BASE_BENEFITS } from "@/lib/alchemy-config"

export default function BaseGmPlatform() {
  const { account, network } = useWallet()
  const { stats, balance, pendingRewards, canClaimRewards, refetch: refetchStats } = useUserStats(account.address)
  const { leaderboard, refetch: refetchLeaderboard } = useLeaderboard()
  const { profile } = useUserProfile(account.address)
  const { sayGM, sayReferralGM, claimRewards, setProfile, isPending, isSuccess } = useGMContract()

  const [profileForm, setProfileForm] = useState({
    xUsername: "",
    discordUsername: "",
    telegramUsername: "",
    evmAddress: "",
    solanaAddress: "",
  })

  const isCorrectNetwork = network.chainId === baseMainnet.chainId
  const canGmToday = stats ? Date.now() - stats.lastGM > 24 * 60 * 60 * 1000 : true
  const referralCode = account.address ? `BASE${account.address.slice(-6)}` : ""

  useEffect(() => {
    if (profile) {
      setProfileForm({
        xUsername: profile.xUsername || "",
        discordUsername: profile.discordUsername || "",
        telegramUsername: profile.telegramUsername || "",
        evmAddress: profile.evmAddress || "",
        solanaAddress: profile.solanaAddress || "",
      })
    }
  }, [profile])

  useEffect(() => {
    if (isSuccess) {
      refetchStats()
      refetchLeaderboard()
    }
  }, [isSuccess, refetchStats, refetchLeaderboard])

  const handleGm = async () => {
    if (!account.isConnected || !isCorrectNetwork || !canGmToday) return
    await sayGM()
  }

  const handleClaimRewards = async () => {
    if (!canClaimRewards) {
      toast({
        title: "Cannot Claim Yet",
        description: "You must wait 60 days between reward claims",
        variant: "destructive",
      })
      return
    }
    await claimRewards()
  }

  const handleUpdateProfile = async () => {
    if (!profileForm.evmAddress) {
      setProfileForm((prev) => ({ ...prev, evmAddress: account.address || "" }))
    }
    await setProfile(profileForm)
  }

  const copyReferralLink = () => {
    const referralLink = `https://gm.base.org/?ref=${referralCode}`
    navigator.clipboard.writeText(referralLink)
    toast({
      title: "Referral Link Copied!",
      description: `Share with friends to earn ${REFERRAL_REWARD} ETH per referral`,
    })
  }

  const getStreakColor = (streak: number) => {
    if (streak >= 30) return "text-blue-300"
    if (streak >= 14) return "text-orange-400"
    if (streak >= 7) return "text-yellow-400"
    return "text-green-400"
  }

  const getStreakBadge = (streak: number) => {
    if (streak >= 30) return { label: "Legend", color: "bg-blue-500" }
    if (streak >= 14) return { label: "Fire", color: "bg-orange-500" }
    if (streak >= 7) return { label: "Hot", color: "bg-yellow-500" }
    return { label: "Rising", color: "bg-green-500" }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-700 via-blue-600 to-blue-500">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <Sun className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">GM Base</h1>
              <p className="text-white/80 text-sm">Daily good morning on Base, Coinbase&apos;s L2</p>
            </div>
          </div>

          <WalletConnect />
        </div>

        {/* Base Benefits Banner */}
        <Card className="mb-6 bg-white/10 backdrop-blur-md border-white/20">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <Zap className="w-8 h-8 text-yellow-300 mx-auto mb-2" />
                <h3 className="text-white font-bold">Fast & Scalable</h3>
                <p className="text-white/70 text-sm">Built on the OP Stack</p>
              </div>
              <div className="text-center">
                <Shield className="w-8 h-8 text-green-300 mx-auto mb-2" />
                <h3 className="text-white font-bold">Secured by Ethereum</h3>
                <p className="text-white/70 text-sm">Ethereum-grade security</p>
              </div>
              <div className="text-center">
                <Coins className="w-8 h-8 text-blue-200 mx-auto mb-2" />
                <h3 className="text-white font-bold">Low Fees</h3>
                <p className="text-white/70 text-sm">Cheap L2 transactions</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Network Switch Alert */}
        {account.isConnected && <NetworkSwitch />}

        {!account.isConnected ? (
          <div className="grid md:grid-cols-2 gap-6">
            {/* Welcome Card */}
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardHeader className="text-center">
                <CardTitle className="text-white">Welcome to GM Base</CardTitle>
                <CardDescription className="text-white/80">
                  Connect your wallet to start your daily GM streak and earn rewards on Base
                </CardDescription>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <div className="p-4 bg-white/5 rounded-lg">
                  <h3 className="text-white font-semibold mb-2">How it works:</h3>
                  <ul className="text-white/80 text-sm space-y-1">
                    <li>{`• Pay ${GM_FEE} ETH daily to say GM`}</li>
                    <li>• Build your streak for badges</li>
                    <li>{`• Refer friends for ${REFERRAL_REWARD} ETH each`}</li>
                    <li>• Compete on the leaderboard</li>
                  </ul>
                </div>
                <WalletConnect />
              </CardContent>
            </Card>

            {/* Market Widget */}
            <MarketWidget />
          </div>
        ) : !isCorrectNetwork ? (
          <Card className="max-w-md mx-auto bg-white/10 backdrop-blur-md border-white/20">
            <CardHeader className="text-center">
              <CardTitle className="text-white">Wrong Network</CardTitle>
              <CardDescription className="text-white/80">Please switch to Base to continue</CardDescription>
            </CardHeader>
          </Card>
        ) : (
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <Tabs defaultValue="gm" className="space-y-6">
                <TabsList className="grid w-full grid-cols-5 bg-white/10 backdrop-blur-md">
                  <TabsTrigger value="gm" className="data-[state=active]:bg-white data-[state=active]:text-blue-600">
                    GM
                  </TabsTrigger>
                  <TabsTrigger
                    value="leaderboard"
                    className="data-[state=active]:bg-white data-[state=active]:text-blue-600"
                  >
                    Leaderboard
                  </TabsTrigger>
                  <TabsTrigger
                    value="referrals"
                    className="data-[state=active]:bg-white data-[state=active]:text-blue-600"
                  >
                    Referrals
                  </TabsTrigger>
                  <TabsTrigger
                    value="profile"
                    className="data-[state=active]:bg-white data-[state=active]:text-blue-600"
                  >
                    Profile
                  </TabsTrigger>
                  <TabsTrigger
                    value="settings"
                    className="data-[state=active]:bg-white data-[state=active]:text-blue-600"
                  >
                    Settings
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="gm" className="space-y-6">
                  <div className="grid gap-6 md:grid-cols-2">
                    {/* GM Card */}
                    <Card className="bg-white/10 backdrop-blur-md border-white/20">
                      <CardHeader className="text-center">
                        <CardTitle className="text-white flex items-center justify-center gap-2">
                          <Sun className="w-6 h-6" />
                          Daily GM
                        </CardTitle>
                        <CardDescription className="text-white/80">
                          Say good morning and maintain your streak
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="text-center space-y-4">
                        <div className="text-4xl font-bold text-white">{stats?.streak || 0}</div>
                        <p className="text-white/80">Day Streak</p>

                        {stats && (
                          <Badge className={`${getStreakBadge(stats.streak).color} text-white`}>
                            <Flame className="w-3 h-3 mr-1" />
                            {getStreakBadge(stats.streak).label}
                          </Badge>
                        )}

                        <Button
                          onClick={handleGm}
                          disabled={!canGmToday || isPending || balance < GM_FEE}
                          size="lg"
                          className="w-full bg-gradient-to-r from-blue-400 to-blue-600 hover:from-blue-500 hover:to-blue-700 text-white font-bold disabled:opacity-50"
                        >
                          {isPending
                            ? "Processing..."
                            : !canGmToday
                              ? "GM'd Today ✓"
                              : balance < GM_FEE
                                ? "Insufficient Balance"
                                : `GM! (${GM_FEE} ETH)`}
                        </Button>

                        {!canGmToday && <p className="text-white/60 text-sm">Come back tomorrow for your next GM!</p>}
                        {balance < GM_FEE && canGmToday && (
                          <p className="text-red-300 text-sm">{`You need at least ${GM_FEE} ETH to say GM`}</p>
                        )}
                      </CardContent>
                    </Card>

                    {/* Stats Card */}
                    <Card className="bg-white/10 backdrop-blur-md border-white/20">
                      <CardHeader>
                        <CardTitle className="text-white">Your Stats</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="flex justify-between items-center">
                          <span className="text-white/80">Balance</span>
                          <span className="text-white font-bold">{balance.toFixed(4)} ETH</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-white/80">Total GMs</span>
                          <span className="text-white font-bold">{stats?.totalGMs || 0}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-white/80">Current Streak</span>
                          <span className={`font-bold ${getStreakColor(stats?.streak || 0)}`}>
                            {stats?.streak || 0} days
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-white/80">Referrals</span>
                          <span className="text-white font-bold">{stats?.referrals || 0}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-white/80">Pending Rewards</span>
                          <span className="text-green-300 font-bold">+{pendingRewards.toFixed(5)} ETH</span>
                        </div>
                        {pendingRewards > 0 && (
                          <Button
                            onClick={handleClaimRewards}
                            disabled={!canClaimRewards || isPending}
                            className="w-full bg-green-600 hover:bg-green-700"
                          >
                            {isPending ? "Processing..." : "Claim Rewards"}
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  </div>

                  {/* Progress to next milestone */}
                  <Card className="bg-white/10 backdrop-blur-md border-white/20">
                    <CardHeader>
                      <CardTitle className="text-white">Next Milestone</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-white/80">Progress to Fire Badge (14 days)</span>
                          <span className="text-white">{Math.min(stats?.streak || 0, 14)}/14</span>
                        </div>
                        <Progress value={((stats?.streak || 0) / 14) * 100} className="bg-white/20" />
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="leaderboard" className="space-y-6">
                  <Card className="bg-white/10 backdrop-blur-md border-white/20">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Trophy className="w-5 h-5" />
                        Leaderboard
                      </CardTitle>
                      <CardDescription className="text-white/80">Top GM streakers on Base</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {leaderboard.map((entry) => (
                          <div key={entry.rank} className="flex items-center gap-4 p-3 rounded-lg bg-white/5">
                            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-white/20 text-white font-bold">
                              {entry.rank <= 3 ? (
                                <Trophy
                                  className={`w-4 h-4 ${
                                    entry.rank === 1
                                      ? "text-yellow-400"
                                      : entry.rank === 2
                                        ? "text-gray-300"
                                        : "text-orange-400"
                                  }`}
                                />
                              ) : (
                                entry.rank
                              )}
                            </div>
                            <Avatar>
                              <AvatarFallback className="bg-white/20 text-white">
                                {entry.address.slice(2, 4).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <p className="text-white font-medium">{formatAddress(entry.address)}</p>
                              <p className="text-white/60 text-sm">{entry.totalGMs} total GMs</p>
                            </div>
                            <div className="text-right">
                              <p className={`font-bold ${getStreakColor(entry.streak)}`}>{entry.streak} days</p>
                              <Badge className={`${getStreakBadge(entry.streak).color} text-white text-xs`}>
                                {getStreakBadge(entry.streak).label}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="referrals" className="space-y-6">
                  <Card className="bg-white/10 backdrop-blur-md border-white/20">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Users className="w-5 h-5" />
                        Referral Program
                      </CardTitle>
                      <CardDescription className="text-white/80">
                        {`Earn ${REFERRAL_REWARD} ETH for each friend you refer`}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="text-center p-4 rounded-lg bg-white/5">
                          <Gift className="w-8 h-8 text-green-300 mx-auto mb-2" />
                          <p className="text-2xl font-bold text-white">{stats?.referrals || 0}</p>
                          <p className="text-white/80 text-sm">Friends Referred</p>
                        </div>
                        <div className="text-center p-4 rounded-lg bg-white/5">
                          <Coins className="w-8 h-8 text-green-300 mx-auto mb-2" />
                          <p className="text-2xl font-bold text-green-300">+{pendingRewards.toFixed(5)}</p>
                          <p className="text-white/80 text-sm">ETH Pending</p>
                        </div>
                      </div>

                      <Separator className="bg-white/20" />

                      <div className="space-y-4">
                        <Label className="text-white">Your Referral Link</Label>
                        <div className="flex gap-2">
                          <Input
                            value={`https://gm.base.org/?ref=${referralCode}`}
                            readOnly
                            className="bg-white/10 border-white/20 text-white"
                          />
                          <Button
                            onClick={copyReferralLink}
                            variant="outline"
                            className="border-white/20 text-white hover:bg-white/10 bg-transparent"
                          >
                            <Copy className="w-4 h-4" />
                          </Button>
                        </div>
                        <Button onClick={copyReferralLink} className="w-full bg-green-600 hover:bg-green-700">
                          <Share2 className="w-4 h-4 mr-2" />
                          Share Referral Link
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="profile" className="space-y-6">
                  <Card className="bg-white/10 backdrop-blur-md border-white/20">
                    <CardHeader>
                      <CardTitle className="text-white">Profile</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="flex items-center gap-4">
                        <Avatar className="w-16 h-16">
                          <AvatarFallback className="bg-white/20 text-white text-xl">
                            {account.address.slice(2, 4).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-white font-bold">{formatAddress(account.address)}</p>
                          <Badge className={`${getStreakBadge(stats?.streak || 0).color} text-white`}>
                            {getStreakBadge(stats?.streak || 0).label} Streaker
                          </Badge>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-white border-white/20">
                              Base
                            </Badge>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() =>
                                window.open(`${baseMainnet.explorerUrl}/address/${account.address}`, "_blank")
                              }
                              className="text-white/60 hover:text-white p-0 h-auto"
                            >
                              <ExternalLink className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>

                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-4">
                          <h3 className="text-white font-semibold">GM Statistics</h3>
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <span className="text-white/80">Total GMs</span>
                              <span className="text-white">{stats?.totalGMs || 0}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-white/80">Current Streak</span>
                              <span className={getStreakColor(stats?.streak || 0)}>{stats?.streak || 0} days</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-white/80">Best Streak</span>
                              <span className="text-white">{stats?.streak || 0} days</span>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <h3 className="text-white font-semibold">Wallet & Earnings</h3>
                          <div className="space-y-2">
                            <div className="flex justify-between">
                              <span className="text-white/80">Balance</span>
                              <span className="text-white">{balance.toFixed(4)} ETH</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-white/80">Pending Rewards</span>
                              <span className="text-green-300">+{pendingRewards.toFixed(5)} ETH</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-white/80">Total Spent</span>
                              <span className="text-white">{((stats?.totalGMs || 0) * GM_FEE).toFixed(4)} ETH</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="settings" className="space-y-6">
                  <Card className="bg-white/10 backdrop-blur-md border-white/20">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <User className="w-5 h-5" />
                        Profile Settings
                      </CardTitle>
                      <CardDescription className="text-white/80">
                        Update your social media profiles and addresses
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label className="text-white">X (Twitter) Username</Label>
                          <Input
                            placeholder="@username"
                            value={profileForm.xUsername}
                            onChange={(e) => setProfileForm((prev) => ({ ...prev, xUsername: e.target.value }))}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white">Discord Username</Label>
                          <Input
                            placeholder="username#1234"
                            value={profileForm.discordUsername}
                            onChange={(e) => setProfileForm((prev) => ({ ...prev, discordUsername: e.target.value }))}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white">Telegram Username</Label>
                          <Input
                            placeholder="@username"
                            value={profileForm.telegramUsername}
                            onChange={(e) => setProfileForm((prev) => ({ ...prev, telegramUsername: e.target.value }))}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-white">EVM Base Address</Label>
                          <Input
                            placeholder="0x..."
                            value={profileForm.evmAddress || account.address || ""}
                            onChange={(e) => setProfileForm((prev) => ({ ...prev, evmAddress: e.target.value }))}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          />
                        </div>
                        <div className="space-y-2 md:col-span-2">
                          <Label className="text-white">Solana Address</Label>
                          <Input
                            placeholder="Base58 address"
                            value={profileForm.solanaAddress}
                            onChange={(e) => setProfileForm((prev) => ({ ...prev, solanaAddress: e.target.value }))}
                            className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                          />
                        </div>
                      </div>
                      <Button
                        onClick={handleUpdateProfile}
                        disabled={isPending}
                        className="w-full bg-blue-600 hover:bg-blue-700"
                      >
                        {isPending ? "Updating..." : "Update Profile"}
                      </Button>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar - Market Widget */}
            <div className="space-y-6">
              <MarketWidget />

              {/* Base Benefits Card */}
              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Zap className="w-5 h-5" />
                    Why Base
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="p-3 bg-white/5 rounded-lg">
                      <h4 className="text-white font-semibold text-sm mb-1">{BASE_BENEFITS.ethereumSecurity.title}</h4>
                      <p className="text-white/70 text-xs">{BASE_BENEFITS.ethereumSecurity.description}</p>
                    </div>
                    <div className="p-3 bg-white/5 rounded-lg">
                      <h4 className="text-white font-semibold text-sm mb-1">{BASE_BENEFITS.lowFees.title}</h4>
                      <p className="text-white/70 text-xs">{BASE_BENEFITS.lowFees.description}</p>
                    </div>
                    <div className="p-3 bg-white/5 rounded-lg">
                      <h4 className="text-white font-semibold text-sm mb-1">{BASE_BENEFITS.coinbaseEcosystem.title}</h4>
                      <p className="text-white/70 text-xs">{BASE_BENEFITS.coinbaseEcosystem.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
