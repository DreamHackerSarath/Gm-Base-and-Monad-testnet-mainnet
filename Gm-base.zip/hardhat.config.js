require("@nomicfoundation/hardhat-toolbox")
require("dotenv").config()

const PRIVATE_KEY = process.env.PRIVATE_KEY || "0x0000000000000000000000000000000000000000000000000000000000000000"
const MONAD_TESTNET_RPC_URL = process.env.MONAD_TESTNET_RPC_URL || "https://testnet-rpc.monad.xyz"

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: {
    version: "0.8.20",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
    },
  },
  networks: {
    hardhat: {
      chainId: 1337,
    },
    monadTestnet: {
      url: MONAD_TESTNET_RPC_URL,
      accounts: [PRIVATE_KEY],
      chainId: 41454,
      gasPrice: "auto",
      gas: "auto",
    },
    // Uncomment when Monad mainnet is available
    // monadMainnet: {
    //   url: "https://mainnet-rpc.monad.xyz", // Placeholder URL
    //   accounts: [PRIVATE_KEY],
    //   chainId: 41455, // Placeholder chain ID
    //   gasPrice: "auto",
    //   gas: "auto",
    // },
  },
  etherscan: {
    // Add Monad explorer API key when available
    apiKey: {
      monadTestnet: "placeholder-api-key",
    },
    customChains: [
      {
        network: "monadTestnet",
        chainId: 41454,
        urls: {
          apiURL: "https://explorer-testnet.monad.xyz/api",
          browserURL: "https://explorer-testnet.monad.xyz",
        },
      },
    ],
  },
  gasReporter: {
    enabled: process.env.REPORT_GAS !== undefined,
    currency: "USD",
  },
}
