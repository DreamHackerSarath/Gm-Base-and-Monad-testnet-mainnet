const hre = require("hardhat")
const fs = require("fs")
const path = require("path")

async function main() {
  console.log("🚀 Starting GM Contract deployment to Monad Testnet...\n")

  // Get the deployer account
  const [deployer] = await hre.ethers.getSigners()
  console.log("📝 Deploying contracts with account:", deployer.address)

  // Check deployer balance
  const balance = await hre.ethers.provider.getBalance(deployer.address)
  console.log("💰 Account balance:", hre.ethers.formatEther(balance), "MON\n")

  if (balance < hre.ethers.parseEther("0.1")) {
    console.warn("⚠️  Warning: Low balance. Make sure you have enough MON for deployment.\n")
  }

  // Owner address for the contract
  const ownerAddress = "0x3d2fF5f190D9B0A9395c80a6FDc4f80C9a9B55a5"
  console.log("👑 Contract owner will be:", ownerAddress)

  try {
    // Deploy the GM contract
    console.log("🔨 Deploying GM contract...")
    const GM = await hre.ethers.getContractFactory("GM")
    const gm = await GM.deploy(ownerAddress)

    await gm.waitForDeployment()
    const contractAddress = await gm.getAddress()

    console.log("✅ GM contract deployed successfully!")
    console.log("📍 Contract address:", contractAddress)
    console.log("🔗 Explorer URL:", `https://explorer-testnet.monad.xyz/address/${contractAddress}\n`)

    // Verify deployment
    console.log("🔍 Verifying deployment...")
    const deployedOwner = await gm.owner()
    const gmFee = await gm.GM_FEE()
    const referGmFee = await gm.REFER_GM_FEE()
    const claimCooldown = await gm.CLAIM_COOLDOWN()

    console.log("✅ Deployment verification:")
    console.log("   Owner:", deployedOwner)
    console.log("   GM Fee:", hre.ethers.formatEther(gmFee), "MON")
    console.log("   Refer GM Fee:", hre.ethers.formatEther(referGmFee), "MON")
    console.log("   Claim Cooldown:", claimCooldown.toString(), "seconds (60 days)\n")

    // Generate ABI file
    const artifactPath = path.join(__dirname, "../artifacts/contracts/GM.sol/GM.json")
    const artifact = JSON.parse(fs.readFileSync(artifactPath, "utf8"))

    const deploymentInfo = {
      contractAddress: contractAddress,
      abi: artifact.abi,
      network: "monadTestnet",
      chainId: 41454,
      deploymentBlock: await hre.ethers.provider.getBlockNumber(),
      deploymentTimestamp: Math.floor(Date.now() / 1000),
      owner: ownerAddress,
      deployer: deployer.address,
    }

    // Save deployment info
    const deploymentsDir = path.join(__dirname, "../deployments")
    if (!fs.existsSync(deploymentsDir)) {
      fs.mkdirSync(deploymentsDir, { recursive: true })
    }

    fs.writeFileSync(path.join(deploymentsDir, "monadTestnet.json"), JSON.stringify(deploymentInfo, null, 2))

    console.log("📄 Contract ABI and deployment info saved to deployments/monadTestnet.json")

    // Print contract interface for frontend integration
    console.log("\n📋 Contract Integration Info:")
    console.log("=".repeat(50))
    console.log("Contract Address:", contractAddress)
    console.log("Network: Monad Testnet")
    console.log("Chain ID: 41454")
    console.log("RPC URL: https://testnet-rpc.monad.xyz")
    console.log("Explorer: https://explorer-testnet.monad.xyz")
    console.log("=".repeat(50))

    console.log("\n🎉 Deployment completed successfully!")
    console.log("💡 Next steps:")
    console.log("   1. Update your frontend with the new contract address")
    console.log("   2. Test the contract functions")
    console.log("   3. Fund the owner address with MON for testing")
  } catch (error) {
    console.error("❌ Deployment failed:", error)
    process.exit(1)
  }
}

// Handle errors
main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("❌ Deployment script failed:", error)
    process.exit(1)
  })
