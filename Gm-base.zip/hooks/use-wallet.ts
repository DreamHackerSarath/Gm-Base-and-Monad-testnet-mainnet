"use client"

import { useState, useEffect } from "react"
import {
  connectWallet,
  disconnectWallet,
  getAccount,
  getNetwork,
  switchNetwork,
  type WalletAccount,
} from "@/lib/wallet-utils"

export function useWallet() {
  const [account, setAccount] = useState<WalletAccount>({ address: "", isConnected: false })
  const [network, setNetwork] = useState({ chainId: 1 })
  const [isConnecting, setIsConnecting] = useState(false)

  useEffect(() => {
    // Initialize wallet state
    setAccount(getAccount())
    setNetwork(getNetwork())
  }, [])

  const connect = async () => {
    setIsConnecting(true)
    try {
      const connectedAccount = await connectWallet()
      setAccount(connectedAccount)
      setNetwork(getNetwork())
    } catch (error) {
      console.error("Failed to connect wallet:", error)
    } finally {
      setIsConnecting(false)
    }
  }

  const disconnect = async () => {
    await disconnectWallet()
    setAccount({ address: "", isConnected: false })
  }

  const switchToNetwork = async (chainId: number) => {
    try {
      await switchNetwork(chainId)
      setNetwork({ chainId })
    } catch (error) {
      console.error("Failed to switch network:", error)
    }
  }

  return {
    account,
    network,
    isConnecting,
    connect,
    disconnect,
    switchToNetwork,
  }
}
