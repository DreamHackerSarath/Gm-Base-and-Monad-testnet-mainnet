"use client"

import { useState } from "react"
import { toast } from "@/hooks/use-toast"

// Fee configuration (in ETH) for Base
export const GM_FEE = 0.001 // 0.001 ETH per GM
export const REFERRAL_FEE = 0.0005 // 0.0005 ETH for a referral GM
export const REFERRAL_REWARD = 0.00025 // 0.00025 ETH credited to the referrer

// Mock contract data
const mockUserStats = {
  streak: 7,
  totalGMs: 15,
  lastGM: Date.now() - 12 * 60 * 60 * 1000, // 12 hours ago
  referrals: 3,
  referralEarnings: 0.00075,
}

const mockLeaderboard = [
  { rank: 1, address: "0x1234...5678", streak: 45, totalGMs: 45 },
  { rank: 2, address: "0x2345...6789", streak: 42, totalGMs: 42 },
  { rank: 3, address: "0x3456...7890", streak: 38, totalGMs: 38 },
  { rank: 4, address: "0x4567...8901", streak: 35, totalGMs: 35 },
  { rank: 5, address: "0x5678...9012", streak: 32, totalGMs: 32 },
]

export function useGMContract() {
  const [isPending, setIsPending] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const simulateTransaction = async (action: string) => {
    setIsPending(true)
    setIsSuccess(false)

    // Simulate transaction delay
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setIsPending(false)
    setIsSuccess(true)

    toast({
      title: "Transaction Successful",
      description: `${action} completed successfully`,
    })

    // Reset success state after a delay
    setTimeout(() => setIsSuccess(false), 3000)
  }

  const sayGM = async () => {
    await simulateTransaction("GM sent")
  }

  const sayReferralGM = async (referrer: string) => {
    await simulateTransaction("Referral GM sent")
  }

  const claimRewards = async () => {
    await simulateTransaction("Rewards claimed")
  }

  const setProfile = async (profile: any) => {
    await simulateTransaction("Profile updated")
  }

  return {
    sayGM,
    sayReferralGM,
    claimRewards,
    setProfile,
    isPending,
    isSuccess,
    hash: isPending ? "0x1234...5678" : undefined,
  }
}

export function useUserStats(address?: string) {
  const [stats] = useState(mockUserStats)
  const [balance] = useState(0.085) // ETH balance
  const [pendingRewards] = useState(0.00075) // ETH pending referral rewards
  const [canClaimRewards] = useState(true)

  return {
    stats,
    balance,
    pendingRewards,
    canClaimRewards,
    isLoading: false,
    refetch: async () => {},
  }
}

export function useLeaderboard() {
  const [leaderboard] = useState(mockLeaderboard)

  return {
    leaderboard,
    isLoading: false,
    refetch: async () => {},
  }
}

export function useUserProfile(address?: string) {
  const [profile] = useState({
    xUsername: "testuser",
    discordUsername: "testuser#1234",
    telegramUsername: "@testuser",
    evmAddress: address || "",
    solanaAddress: "11111111111111111111111111111112",
  })

  return {
    profile,
    isLoading: false,
    refetch: async () => {},
  }
}
