"use client"

import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Wallet, ChevronDown } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { useWallet } from "@/hooks/use-wallet"
import { formatAddress } from "@/lib/wallet-utils"

export function WalletConnect() {
  const { account, connect, disconnect, isConnecting } = useWallet()

  if (!account.isConnected) {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button className="bg-white text-blue-600 hover:bg-white/90" disabled={isConnecting}>
            <Wallet className="w-4 h-4 mr-2" />
            {isConnecting ? "Connecting..." : "Connect Wallet"}
            <ChevronDown className="w-4 h-4 ml-2" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuItem onClick={connect} className="cursor-pointer">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full" />
              MetaMask
            </div>
          </DropdownMenuItem>
          <DropdownMenuItem onClick={connect} className="cursor-pointer">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full" />
              WalletConnect
            </div>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    )
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className="flex items-center gap-3 bg-white/10 backdrop-blur-md border-white/20 text-white hover:bg-white/20"
        >
          <div className="text-right">
            <p className="text-white/80 text-sm">Balance</p>
            <p className="text-white font-bold">0.0850 ETH</p>
          </div>
          <Avatar>
            <AvatarFallback className="bg-white/20 text-white">
              {account.address.slice(2, 4).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <ChevronDown className="w-4 h-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <div className="p-3">
          <div className="flex items-center gap-3 mb-2">
            <Avatar>
              <AvatarFallback className="bg-blue-100 text-blue-600">
                {account.address.slice(2, 4).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">{formatAddress(account.address)}</p>
              <Badge variant="secondary" className="text-xs">
                Base
              </Badge>
            </div>
          </div>
          <div className="text-sm text-gray-600">
            <p>Balance: 0.0850 ETH</p>
          </div>
        </div>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={disconnect} className="cursor-pointer text-red-600 focus:text-red-600">
          Disconnect Wallet
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
