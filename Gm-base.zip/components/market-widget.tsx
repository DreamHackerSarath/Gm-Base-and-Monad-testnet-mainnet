"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, DollarSign, Activity, BarChart3 } from "lucide-react"
import { marketDataService, type CryptoPrice, type MarketMetrics, type FearGreedIndex } from "@/lib/market-data"

export function MarketWidget() {
  const [topCryptos, setTopCryptos] = useState<CryptoPrice[]>([])
  const [globalMetrics, setGlobalMetrics] = useState<MarketMetrics | null>(null)
  const [fearGreed, setFearGreed] = useState<FearGreedIndex | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchMarketData = async () => {
      try {
        const [cryptos, metrics, fearGreedData] = await Promise.all([
          marketDataService.getTopCryptocurrencies(5),
          marketDataService.getGlobalMetrics(),
          marketDataService.getFearGreedIndex(),
        ])

        setTopCryptos(cryptos)
        setGlobalMetrics(metrics)
        setFearGreed(fearGreedData)
      } catch (error) {
        console.error("Failed to fetch market data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchMarketData()
    const interval = setInterval(fetchMarketData, 60000) // Update every minute

    return () => clearInterval(interval)
  }, [])

  if (isLoading) {
    return (
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Market Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-12 bg-white/10 rounded" />
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Global Market Metrics */}
      {globalMetrics && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-4 text-center">
              <DollarSign className="w-6 h-6 text-green-400 mx-auto mb-2" />
              <p className="text-white font-bold text-lg">
                {marketDataService.formatMarketCap(globalMetrics.total_market_cap)}
              </p>
              <p className="text-white/60 text-sm">Market Cap</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-4 text-center">
              <Activity className="w-6 h-6 text-blue-400 mx-auto mb-2" />
              <p className="text-white font-bold text-lg">
                {marketDataService.formatMarketCap(globalMetrics.total_volume_24h)}
              </p>
              <p className="text-white/60 text-sm">24h Volume</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-4 text-center">
              <BarChart3 className="w-6 h-6 text-orange-400 mx-auto mb-2" />
              <p className="text-white font-bold text-lg">{globalMetrics.bitcoin_dominance.toFixed(1)}%</p>
              <p className="text-white/60 text-sm">BTC Dominance</p>
            </CardContent>
          </Card>

          {fearGreed && (
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardContent className="p-4 text-center">
                <div className="w-6 h-6 bg-yellow-400 rounded-full mx-auto mb-2" />
                <p className="text-white font-bold text-lg">{fearGreed.value}</p>
                <p className="text-white/60 text-sm">{fearGreed.value_classification}</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Top Cryptocurrencies */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Top Cryptocurrencies
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {topCryptos.map((crypto, index) => {
              const change24h = marketDataService.formatPercentChange(crypto.percent_change_24h)
              return (
                <div key={crypto.id} className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                  <div className="flex items-center gap-3">
                    <span className="text-white/60 font-mono text-sm w-6">{index + 1}</span>
                    <div>
                      <p className="text-white font-medium">{crypto.name}</p>
                      <p className="text-white/60 text-sm">{crypto.symbol}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className="text-white font-bold">{marketDataService.formatPrice(crypto.price)}</p>
                    <div className="flex items-center gap-1">
                      {crypto.percent_change_24h >= 0 ? (
                        <TrendingUp className="w-3 h-3 text-green-500" />
                      ) : (
                        <TrendingDown className="w-3 h-3 text-red-500" />
                      )}
                      <span className={`text-sm ${change24h.color}`}>{change24h.value}</span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Base Highlight */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <div className="w-6 h-6 bg-blue-500 rounded-full" />
            Base - Coinbase&apos;s L2
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-white/80">Stack</span>
              <Badge className="bg-blue-600 text-white">OP Stack</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white/80">Security</span>
              <Badge className="bg-green-600 text-white">Ethereum L2</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white/80">Gas Fees</span>
              <Badge className="bg-blue-600 text-white">Low</Badge>
            </div>
            <p className="text-white/60 text-sm mt-3">
              Build on Base, the Ethereum L2 incubated by Coinbase. Full EVM compatibility, low fees, and
              Ethereum-grade security.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
