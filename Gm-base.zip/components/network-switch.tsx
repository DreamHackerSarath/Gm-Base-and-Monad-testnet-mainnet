"use client"

import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangle } from "lucide-react"
import { useWallet } from "@/hooks/use-wallet"
import { baseMainnet } from "@/lib/wallet-utils"

export function NetworkSwitch() {
  const { network, switchToNetwork } = useWallet()

  if (network.chainId === baseMainnet.chainId) {
    return null
  }

  return (
    <Alert className="mb-6 bg-yellow-50 border-yellow-200">
      <AlertTriangle className="h-4 w-4 text-yellow-600" />
      <AlertDescription className="flex items-center justify-between">
        <span className="text-yellow-800">Please switch to Base to use this application</span>
        <Button onClick={() => switchToNetwork(baseMainnet.chainId)} size="sm" className="ml-4">
          Switch Network
        </Button>
      </AlertDescription>
    </Alert>
  )
}
