// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/utils/Pausable.sol";

/**
 * @title GM Contract
 * @dev A contract for daily "Good Morning" interactions with referral rewards and profile management
 * @author GM Monad Team
 * @notice This contract allows users to send daily GMs, earn referral rewards, and manage profiles
 */
contract GM is Ownable, ReentrancyGuard, Pausable {
    /// @dev Minimum time between reward claims (60 days in seconds)
    uint256 public constant CLAIM_COOLDOWN = 60 days;
    
    /// @dev Required fee for GM function (1 MON)
    uint256 public constant GM_FEE = 1 ether;
    
    /// @dev Required fee for referral GM function (0.5 MON)
    uint256 public constant REFER_GM_FEE = 0.5 ether;

    /// @dev Maximum length for string fields in profiles
    uint256 public constant MAX_STRING_LENGTH = 100;

    /// @dev Total number of GMs sent
    uint256 public gmCount;

    /// @dev Total pending rewards in the contract
    uint256 public totalPendingRewards;

    /// @dev Mapping to store pending referral rewards for each address
    mapping(address => uint256) public pendingRewards;
    
    /// @dev Mapping to store last claim time for each address
    mapping(address => uint256) public lastClaimTime;

    /// @dev Mapping to track daily GM status for each user
    mapping(address => uint256) public lastGMTime;

    /**
     * @dev User profile structure
     * @param xUsername Twitter/X username
     * @param discordUsername Discord username
     * @param telegramUsername Telegram username
     * @param evmMonadAddress EVM Monad address
     * @param solanaAddress Solana address (Base58 string)
     */
    struct Profile {
        string xUsername;
        string discordUsername;
        string telegramUsername;
        address evmMonadAddress;
        string solanaAddress;
    }

    /// @dev Mapping to store user profiles
    mapping(address => Profile) public profiles;

    /**
     * @dev Emitted when a GM is sent
     * @param from Address that sent the GM
     * @param timestamp Block timestamp when GM was sent
     */
    event GMSent(address indexed from, uint256 timestamp);

    /**
     * @dev Emitted when a referral GM is sent
     * @param from Address that sent the referral GM
     * @param referrer Address of the referrer
     * @param timestamp Block timestamp when referral GM was sent
     */
    event GMReferred(address indexed from, address indexed referrer, uint256 timestamp);

    /**
     * @dev Emitted when referral rewards are claimed
     * @param claimer Address that claimed the rewards
     * @param amount Amount of rewards claimed
     * @param timestamp Block timestamp when rewards were claimed
     */
    event RewardsClaimed(address indexed claimer, uint256 amount, uint256 timestamp);

    /**
     * @dev Emitted when a user profile is updated
     * @param user Address of the user
     * @param xUsername Twitter/X username
     * @param discordUsername Discord username
     * @param telegramUsername Telegram username
     * @param evmMonadAddress EVM Monad address
     * @param solanaAddress Solana address
     */
    event ProfileUpdated(
        address indexed user,
        string xUsername,
        string discordUsername,
        string telegramUsername,
        address evmMonadAddress,
        string solanaAddress
    );

    /**
     * @dev Emitted when fee forwarding fails
     * @param amount Amount that failed to forward
     * @param timestamp Block timestamp of failure
     */
    event FeeForwardFailed(uint256 amount, uint256 timestamp);

    /**
     * @dev Contract constructor
     * @param initialOwner Address that will own the contract
     */
    constructor(address initialOwner) Ownable(initialOwner) {
        require(initialOwner != address(0), "GM: Invalid owner address");
    }

    /**
     * @dev Send a GM message with 1 MON fee
     * @notice Requires exactly 1 MON to be sent with the transaction
     * @notice Can only be called once per day per address
     */
    function gm() external payable nonReentrant whenNotPaused {
        require(msg.value == GM_FEE, "GM: Incorrect fee amount. Must send exactly 1 MON");
        require(
            block.timestamp >= lastGMTime[msg.sender] + 1 days,
            "GM: Can only GM once per day"
        );
        
        lastGMTime[msg.sender] = block.timestamp;
        gmCount++;
        
        // Forward full fee to owner with proper error handling
        (bool success, ) = owner().call{value: msg.value, gas: 10000}("");
        if (!success) {
            emit FeeForwardFailed(msg.value, block.timestamp);
            // Don't revert - store fee for manual withdrawal
        }
        
        emit GMSent(msg.sender, block.timestamp);
    }

    /**
     * @dev Send a referral GM with 0.5 MON fee
     * @param referrer Address of the referrer who will receive rewards
     * @notice Requires exactly 0.5 MON to be sent with the transaction
     * @notice Can only be called once per day per address
     */
    function referGM(address referrer) external payable nonReentrant whenNotPaused {
        require(msg.value == REFER_GM_FEE, "GM: Incorrect fee amount. Must send exactly 0.5 MON");
        require(referrer != address(0), "GM: Invalid referrer address");
        require(referrer != msg.sender, "GM: Cannot refer yourself");
        require(
            block.timestamp >= lastGMTime[msg.sender] + 1 days,
            "GM: Can only GM once per day"
        );
        
        lastGMTime[msg.sender] = block.timestamp;
        gmCount++;
        
        uint256 ownerShare = msg.value / 2; // 0.25 MON
        uint256 referrerReward = msg.value / 2; // 0.25 MON
        
        // Forward owner share immediately with proper error handling
        (bool success, ) = owner().call{value: ownerShare, gas: 10000}("");
        if (!success) {
            emit FeeForwardFailed(ownerShare, block.timestamp);
            // Don't revert - store fee for manual withdrawal
        }
        
        // Store referrer reward for later claim
        pendingRewards[referrer] += referrerReward;
        totalPendingRewards += referrerReward;
        
        emit GMReferred(msg.sender, referrer, block.timestamp);
    }

    /**
     * @dev Claim accumulated referral rewards
     * @notice Can only be called once every 60 days per address
     */
    function claimRewards() external nonReentrant whenNotPaused {
        uint256 rewards = pendingRewards[msg.sender];
        require(rewards > 0, "GM: No rewards to claim");
        
        uint256 nextClaimAllowed = lastClaimTime[msg.sender] + CLAIM_COOLDOWN;
        require(block.timestamp >= nextClaimAllowed, "GM: Claim cooldown not met");
        
        // Reset pending rewards and update claim time
        pendingRewards[msg.sender] = 0;
        lastClaimTime[msg.sender] = block.timestamp;
        totalPendingRewards -= rewards;
        
        // Transfer rewards to claimer with proper error handling
        (bool success, ) = msg.sender.call{value: rewards, gas: 10000}("");
        require(success, "GM: Failed to transfer rewards");
        
        emit RewardsClaimed(msg.sender, rewards, block.timestamp);
    }

    /**
     * @dev Set or update user profile
     * @param xUsername Twitter/X username
     * @param discordUsername Discord username
     * @param telegramUsername Telegram username
     * @param evmMonadAddress EVM Monad address
     * @param solanaAddress Solana address (Base58 string)
     */
    function setProfile(
        string calldata xUsername,
        string calldata discordUsername,
        string calldata telegramUsername,
        address evmMonadAddress,
        string calldata solanaAddress
    ) external whenNotPaused {
        // Validate string lengths
        require(bytes(xUsername).length <= MAX_STRING_LENGTH, "GM: xUsername too long");
        require(bytes(discordUsername).length <= MAX_STRING_LENGTH, "GM: discordUsername too long");
        require(bytes(telegramUsername).length <= MAX_STRING_LENGTH, "GM: telegramUsername too long");
        require(bytes(solanaAddress).length <= MAX_STRING_LENGTH, "GM: solanaAddress too long");
        
        profiles[msg.sender] = Profile({
            xUsername: xUsername,
            discordUsername: discordUsername,
            telegramUsername: telegramUsername,
            evmMonadAddress: evmMonadAddress,
            solanaAddress: solanaAddress
        });
        
        emit ProfileUpdated(
            msg.sender,
            xUsername,
            discordUsername,
            telegramUsername,
            evmMonadAddress,
            solanaAddress
        );
    }

    /**
     * @dev Get user profile
     * @param user Address of the user
     * @return Profile struct containing user information
     */
    function getProfile(address user) external view returns (Profile memory) {
        return profiles[user];
    }

    /**
     * @dev Get pending referral rewards for an address
     * @param referrer Address to check rewards for
     * @return Amount of pending rewards in wei
     */
    function referralRewards(address referrer) external view returns (uint256) {
        return pendingRewards[referrer];
    }

    /**
     * @dev Get next allowed claim time for an address
     * @param claimer Address to check next claim time for
     * @return Timestamp when next claim is allowed
     */
    function nextClaimTime(address claimer) external view returns (uint256) {
        return lastClaimTime[claimer] + CLAIM_COOLDOWN;
    }

    /**
     * @dev Check if an address can claim rewards now
     * @param claimer Address to check
     * @return True if can claim now, false otherwise
     */
    function canClaimNow(address claimer) external view returns (bool) {
        return block.timestamp >= lastClaimTime[claimer] + CLAIM_COOLDOWN;
    }

    /**
     * @dev Check if an address can GM today
     * @param user Address to check
     * @return True if can GM today, false otherwise
     */
    function canGMToday(address user) external view returns (bool) {
        return block.timestamp >= lastGMTime[user] + 1 days;
    }

    /**
     * @dev Get user GM statistics
     * @param user Address to get stats for
     * @return streak Current streak (simplified calculation)
     * @return totalGMs Total GMs sent (simplified - would need indexer for accurate count)
     * @return lastGM Timestamp of last GM
     * @return referrals Total referrals (simplified - would need indexer for accurate count)
     * @return referralEarnings Total referral earnings
     */
    function getUserStats(address user) external view returns (
        uint256 streak,
        uint256 totalGMs,
        uint256 lastGM,
        uint256 referrals,
        uint256 referralEarnings
    ) {
        // Simplified implementation - real stats would come from indexer
        lastGM = lastGMTime[user];
        referralEarnings = pendingRewards[user];
        
        // Streak calculation would be complex on-chain, better handled by indexer
        streak = 0;
        totalGMs = 0;
        referrals = 0;
    }

    /**
     * @dev Emergency function to withdraw contract balance (owner only)
     * @notice Only withdraws funds that are not pending rewards
     */
    function emergencyWithdraw() external onlyOwner {
        uint256 availableBalance = address(this).balance - totalPendingRewards;
        require(availableBalance > 0, "GM: No funds available for withdrawal");
        
        (bool success, ) = owner().call{value: availableBalance}("");
        require(success, "GM: Emergency withdrawal failed");
    }

    /**
     * @dev Pause contract functions (owner only)
     */
    function pause() external onlyOwner {
        _pause();
    }

    /**
     * @dev Unpause contract functions (owner only)
     */
    function unpause() external onlyOwner {
        _unpause();
    }

    /**
     * @dev Get contract balance
     * @return Current contract balance in wei
     */
    function getContractBalance() external view returns (uint256) {
        return address(this).balance;
    }

    /**
     * @dev Get metrics for monitoring
     * @return totalGMs Total GMs sent
     * @return totalPending Total pending rewards
     * @return contractBalance Current contract balance
     */
    function getMetrics() external view returns (
        uint256 totalGMs,
        uint256 totalPending,
        uint256 contractBalance
    ) {
        return (gmCount, totalPendingRewards, address(this).balance);
    }

    /**
     * @dev Fallback function to reject direct ETH transfers
     */
    receive() external payable {
        revert("GM: Direct transfers not allowed. Use gm() or referGM() functions");
    }
}
