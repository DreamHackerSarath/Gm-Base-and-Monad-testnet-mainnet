require("@nomicfoundation/hardhat-toolbox")
require("dotenv").config()

const PRIVATE_KEY = process.env.PRIVATE_KEY || "0x0000000000000000000000000000000000000000000000000000000000000000"
// Official Monad Testnet RPC from developers.monad.xyz
const MONAD_TESTNET_RPC_URL = process.env.MONAD_TESTNET_RPC_URL || "https://testnet-rpc.monad.xyz"

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: {
    version: "0.8.20",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200,
      },
      viaIR: true, // Enable via-IR for better optimization on Monad
    },
  },
  networks: {
    hardhat: {
      chainId: 1337,
      // Fork Monad testnet for local testing
      forking: {
        url: MONAD_TESTNET_RPC_URL,
        enabled: false, // Enable when needed
      },
    },
    // Official Monad Testnet configuration
    monadTestnet: {
      url: MONAD_TESTNET_RPC_URL,
      accounts: [PRIVATE_KEY],
      chainId: 41454, // Official Chain ID from developers.monad.xyz
      gasPrice: "auto",
      gas: "auto",
      timeout: 60000,
      confirmations: 2,
    },
    // Placeholder for Monad Mainnet (when available)
    monadMainnet: {
      url: "https://rpc.monad.xyz", // Placeholder - will be updated when mainnet launches
      accounts: [PRIVATE_KEY],
      chainId: 41455, // Placeholder - will be updated when mainnet launches
      gasPrice: "auto",
      gas: "auto",
      timeout: 60000,
      confirmations: 3,
    },
  },
  etherscan: {
    apiKey: {
      // Monad explorer API configuration (when available)
      monadTestnet: "placeholder-api-key",
      monadMainnet: "placeholder-api-key",
    },
    customChains: [
      {
        network: "monadTestnet",
        chainId: 41454,
        urls: {
          apiURL: "https://testnet.monadexplorer.com/api", // Official explorer from developers.monad.xyz
          browserURL: "https://testnet.monadexplorer.com",
        },
      },
    ],
  },
  gasReporter: {
    enabled: process.env.REPORT_GAS !== undefined,
    currency: "USD",
    coinmarketcap: process.env.COINMARKETCAP_API_KEY,
  },
  mocha: {
    timeout: 60000, // Increased timeout for Monad network calls
  },
}
