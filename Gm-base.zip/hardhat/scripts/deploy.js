const hre = require("hardhat")
const fs = require("fs")
const path = require("path")

async function main() {
  console.log("🚀 Starting GM Contract deployment to Monad Testnet...\n")

  // Display Alchemy & CoinMarketCap integration info
  console.log("🔗 Enhanced Infrastructure:")
  console.log("   📊 CoinMarketCap API: Real-time market data")
  console.log("   ⚡ Alchemy RPC: Enhanced reliability and performance")
  console.log("   🌐 Monad Benefits: 10,000 TPS, Low gas fees, Full EVM compatibility\n")

  console.log("📋 Official Monad Testnet Details:")
  console.log("   Chain ID: 41454")
  console.log("   RPC URL: https://testnet-rpc.monad.xyz")
  console.log("   Explorer: https://testnet.monadexplorer.com")
  console.log("   Currency: MON\n")

  // Get the deployer account
  const [deployer] = await hre.ethers.getSigners()
  console.log("📝 Deploying contracts with account:", deployer.address)

  // Check deployer balance
  const balance = await hre.ethers.provider.getBalance(deployer.address)
  console.log("💰 Account balance:", hre.ethers.formatEther(balance), "MON\n")

  if (balance < hre.ethers.parseEther("0.1")) {
    console.warn("⚠️  Warning: Low balance. Get testnet MON from:")
    console.warn("   🚰 Monad Testnet Faucet: https://faucet.monad.xyz")
    console.warn("   💬 Developer Discord: https://discord.gg/monad\n")
  }

  // Verify network connection
  try {
    const network = await hre.ethers.provider.getNetwork()
    console.log("🌐 Connected to network:", network.name)
    console.log("🔗 Chain ID:", network.chainId.toString())

    if (network.chainId !== 41454n) {
      throw new Error(`Wrong network! Expected Chain ID 41454, got ${network.chainId}`)
    }
  } catch (error) {
    console.error("❌ Network connection failed:", error.message)
    console.log("💡 Make sure you're connected to Monad Testnet:")
    console.log("   RPC URL: https://testnet-rpc.monad.xyz")
    console.log("   Chain ID: 41454")
    process.exit(1)
  }

  // Owner address - Updated with provided address
  const ownerAddress = process.env.OWNER_ADDRESS || "0x3d2fF5f190D9B0A9395c80a6FDc4f80C9a9B55a5"
  console.log("👑 Contract owner will be:", ownerAddress)

  // Validate owner address
  if (!hre.ethers.isAddress(ownerAddress)) {
    console.error("❌ Invalid owner address:", ownerAddress)
    process.exit(1)
  }

  try {
    // Deploy the GM contract
    console.log("🔨 Deploying GM contract with Monad optimizations...")
    const GM = await hre.ethers.getContractFactory("GM")

    // Estimate gas for deployment on Monad's high-performance network
    const deploymentData = GM.interface.encodeDeploy([ownerAddress])
    const gasEstimate = await hre.ethers.provider.estimateGas({
      data: deploymentData,
    })
    console.log("⛽ Estimated deployment gas:", gasEstimate.toString())
    console.log("💡 Monad's low gas fees make deployment cost-effective!")

    const gm = await GM.deploy(ownerAddress, {
      gasLimit: (gasEstimate * 120n) / 100n, // Add 20% buffer
    })

    console.log("⏳ Waiting for deployment transaction on Monad's 10,000 TPS network...")
    await gm.waitForDeployment()
    const contractAddress = await gm.getAddress()

    console.log("✅ GM contract deployed successfully!")
    console.log("📍 Contract address:", contractAddress)
    console.log("🔗 Explorer URL:", `https://testnet.monadexplorer.com/address/${contractAddress}`)
    console.log("🔗 Transaction URL:", `https://testnet.monadexplorer.com/tx/${gm.deploymentTransaction()?.hash}\n`)

    // Verify deployment
    console.log("🔍 Verifying deployment...")
    const deployedOwner = await gm.owner()
    const gmFee = await gm.GM_FEE()
    const referGmFee = await gm.REFER_GM_FEE()
    const claimCooldown = await gm.CLAIM_COOLDOWN()

    console.log("✅ Deployment verification:")
    console.log("   Owner:", deployedOwner)
    console.log("   GM Fee:", hre.ethers.formatEther(gmFee), "MON")
    console.log("   Refer GM Fee:", hre.ethers.formatEther(referGmFee), "MON")
    console.log("   Claim Cooldown:", claimCooldown.toString(), "seconds (60 days)\n")

    // Generate comprehensive deployment info
    const artifactPath = path.join(__dirname, "../artifacts/contracts/GM.sol/GM.json")
    const artifact = JSON.parse(fs.readFileSync(artifactPath, "utf8"))

    const deploymentInfo = {
      contractAddress: contractAddress,
      abi: artifact.abi,
      network: "monadTestnet",
      chainId: 41454,
      rpcUrl: "https://testnet-rpc.monad.xyz",
      explorerUrl: "https://testnet.monadexplorer.com",
      deploymentBlock: await hre.ethers.provider.getBlockNumber(),
      deploymentTimestamp: Math.floor(Date.now() / 1000),
      deploymentTx: gm.deploymentTransaction()?.hash,
      owner: ownerAddress,
      deployer: deployer.address,
      fees: {
        gmFee: gmFee.toString(),
        referGmFee: referGmFee.toString(),
      },
      constants: {
        claimCooldown: claimCooldown.toString(),
        maxStringLength: "100",
      },
      integrations: {
        coinmarketcap: {
          enabled: !!process.env.COINMARKETCAP_API_KEY,
          description: "Real-time market data and price feeds",
        },
        alchemy: {
          enabled: !!process.env.ALCHEMY_API_KEY,
          description: "Enhanced RPC services and webhooks",
        },
      },
      monadBenefits: {
        tps: "10,000",
        evmCompatibility: "100%",
        gasFees: "Near-zero",
        description: "The fastest EVM L1 with zero compromises",
      },
    }

    // Save deployment info
    const deploymentsDir = path.join(__dirname, "../deployments")
    if (!fs.existsSync(deploymentsDir)) {
      fs.mkdirSync(deploymentsDir, { recursive: true })
    }

    fs.writeFileSync(path.join(deploymentsDir, "monadTestnet.json"), JSON.stringify(deploymentInfo, null, 2))

    console.log("📄 Contract ABI and deployment info saved to deployments/monadTestnet.json")

    // Print integration info
    console.log("\n📋 Frontend Integration Info:")
    console.log("=".repeat(70))
    console.log("Contract Address:", contractAddress)
    console.log("Network: Monad Testnet")
    console.log("Chain ID: 41454")
    console.log("RPC URL: https://testnet-rpc.monad.xyz")
    console.log("Explorer: https://testnet.monadexplorer.com")
    console.log("Currency Symbol: MON")
    console.log("Owner Address: 0x3d2fF5f190D9B0A9395c80a6FDc4f80C9a9B55a5")
    console.log("=".repeat(70))

    // Print environment variable updates
    console.log("\n🔧 Environment Variable Updates:")
    console.log("Add these to your .env files:")
    console.log(`GM_CONTRACT_ADDRESS=${contractAddress}`)
    console.log(`OWNER_ADDRESS=0x3d2fF5f190D9B0A9395c80a6FDc4f80C9a9B55a5`)
    console.log(`COINMARKETCAP_API_KEY=your_coinmarketcap_api_key`)
    console.log(`ALCHEMY_API_KEY=your_alchemy_api_key`)

    console.log("\n🎉 Deployment completed successfully!")
    console.log("💡 Next steps:")
    console.log("   1. Update your frontend with the new contract address")
    console.log("   2. Configure CoinMarketCap API for market data")
    console.log("   3. Set up Alchemy for enhanced RPC services")
    console.log("   4. Test the contract functions on Monad Testnet")
    console.log("   5. Get testnet MON from https://faucet.monad.xyz")
    console.log("   6. Join the developer community: https://discord.gg/monad")
    console.log("   7. Explore Monad docs: https://developers.monad.xyz")

    console.log("\n🚀 Monad Advantages:")
    console.log("   ⚡ 10,000 TPS - Lightning fast transactions")
    console.log("   💰 Near-zero gas fees - Cost-effective operations")
    console.log("   🔧 Full EVM compatibility - Deploy existing contracts")
    console.log("   📊 Enhanced with CoinMarketCap & Alchemy integration")
  } catch (error) {
    console.error("❌ Deployment failed:", error)

    if (error.message.includes("insufficient funds")) {
      console.log("\n💡 Get testnet MON from:")
      console.log("   🚰 Faucet: https://faucet.monad.xyz")
      console.log("   💬 Discord: https://discord.gg/monad")
    }

    process.exit(1)
  }
}

// Handle errors gracefully
main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("❌ Deployment script failed:", error)
    process.exit(1)
  })
