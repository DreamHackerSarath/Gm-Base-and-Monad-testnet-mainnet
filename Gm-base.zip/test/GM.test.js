const { expect } = require("chai")
const { ethers } = require("hardhat")

describe("GM Contract", () => {
  let GM, gm, owner, addr1, addr2, addr3
  const GM_FEE = ethers.parseEther("1")
  const REFER_GM_FEE = ethers.parseEther("0.5")
  const CLAIM_COOLDOWN = 60 * 24 * 60 * 60 // 60 days in seconds

  beforeEach(async () => {
    ;[owner, addr1, addr2, addr3] = await ethers.getSigners()
    GM = await ethers.getContractFactory("GM")
    gm = await GM.deploy(owner.address)
    await gm.waitForDeployment()
  })

  describe("Deployment", () => {
    it("Should set the right owner", async () => {
      expect(await gm.owner()).to.equal(owner.address)
    })

    it("Should set correct fee amounts", async () => {
      expect(await gm.GM_FEE()).to.equal(GM_FEE)
      expect(await gm.REFER_GM_FEE()).to.equal(REFER_GM_FEE)
    })

    it("Should set correct claim cooldown", async () => {
      expect(await gm.CLAIM_COOLDOWN()).to.equal(CLAIM_COOLDOWN)
    })
  })

  describe("GM Function", () => {
    it("Should accept correct GM fee", async () => {
      await expect(gm.connect(addr1).gm({ value: GM_FEE }))
        .to.emit(gm, "GMSent")
        .withArgs(addr1.address, await time.latest())
    })

    it("Should reject incorrect GM fee", async () => {
      await expect(gm.connect(addr1).gm({ value: ethers.parseEther("0.5") })).to.be.revertedWith(
        "GM: Incorrect fee amount. Must send exactly 1 MON",
      )
    })

    it("Should increment GM count", async () => {
      await gm.connect(addr1).gm({ value: GM_FEE })
      expect(await gm.gmCount()).to.equal(1)
    })

    it("Should forward fee to owner", async () => {
      const initialBalance = await ethers.provider.getBalance(owner.address)
      await gm.connect(addr1).gm({ value: GM_FEE })
      const finalBalance = await ethers.provider.getBalance(owner.address)
      expect(finalBalance).to.be.gt(initialBalance)
    })
  })

  describe("Referral GM Function", () => {
    it("Should accept correct referral GM fee", async () => {
      await expect(gm.connect(addr1).referGM(addr2.address, { value: REFER_GM_FEE }))
        .to.emit(gm, "GMReferred")
        .withArgs(addr1.address, addr2.address, await time.latest())
    })

    it("Should reject incorrect referral GM fee", async () => {
      await expect(gm.connect(addr1).referGM(addr2.address, { value: GM_FEE })).to.be.revertedWith(
        "GM: Incorrect fee amount. Must send exactly 0.5 MON",
      )
    })

    it("Should reject zero address referrer", async () => {
      await expect(gm.connect(addr1).referGM(ethers.ZeroAddress, { value: REFER_GM_FEE })).to.be.revertedWith(
        "GM: Invalid referrer address",
      )
    })

    it("Should reject self-referral", async () => {
      await expect(gm.connect(addr1).referGM(addr1.address, { value: REFER_GM_FEE })).to.be.revertedWith(
        "GM: Cannot refer yourself",
      )
    })

    it("Should split payment correctly", async () => {
      const initialOwnerBalance = await ethers.provider.getBalance(owner.address)
      await gm.connect(addr1).referGM(addr2.address, { value: REFER_GM_FEE })

      // Check owner received 0.25 MON
      const finalOwnerBalance = await ethers.provider.getBalance(owner.address)
      expect(finalOwnerBalance).to.be.gt(initialOwnerBalance)

      // Check referrer has pending rewards
      expect(await gm.pendingRewards(addr2.address)).to.equal(ethers.parseEther("0.25"))
    })
  })

  describe("Rewards Claiming", () => {
    beforeEach(async () => {
      // Set up some pending rewards
      await gm.connect(addr1).referGM(addr2.address, { value: REFER_GM_FEE })
    })

    it("Should allow claiming rewards after cooldown", async () => {
      // Fast forward time by 60 days
      await ethers.provider.send("evm_increaseTime", [CLAIM_COOLDOWN])
      await ethers.provider.send("evm_mine")

      const initialBalance = await ethers.provider.getBalance(addr2.address)
      await expect(gm.connect(addr2).claimRewards())
        .to.emit(gm, "RewardsClaimed")
        .withArgs(addr2.address, ethers.parseEther("0.25"), await time.latest())

      const finalBalance = await ethers.provider.getBalance(addr2.address)
      expect(finalBalance).to.be.gt(initialBalance)
      expect(await gm.pendingRewards(addr2.address)).to.equal(0)
    })

    it("Should reject claiming before cooldown", async () => {
      await expect(gm.connect(addr2).claimRewards()).to.be.revertedWith("GM: Claim cooldown not met")
    })

    it("Should reject claiming with no rewards", async () => {
      await expect(gm.connect(addr3).claimRewards()).to.be.revertedWith("GM: No rewards to claim")
    })
  })

  describe("Profile Management", () => {
    const sampleProfile = {
      xUsername: "testuser",
      discordUsername: "testuser#1234",
      telegramUsername: "@testuser",
      evmMonadAddress: "0x1234567890123456789012345678901234567890",
      solanaAddress: "11111111111111111111111111111112",
    }

    it("Should allow setting profile", async () => {
      await expect(
        gm
          .connect(addr1)
          .setProfile(
            sampleProfile.xUsername,
            sampleProfile.discordUsername,
            sampleProfile.telegramUsername,
            sampleProfile.evmMonadAddress,
            sampleProfile.solanaAddress,
          ),
      )
        .to.emit(gm, "ProfileUpdated")
        .withArgs(
          addr1.address,
          sampleProfile.xUsername,
          sampleProfile.discordUsername,
          sampleProfile.telegramUsername,
          sampleProfile.evmMonadAddress,
          sampleProfile.solanaAddress,
        )
    })

    it("Should allow updating profile", async () => {
      // Set initial profile
      await gm
        .connect(addr1)
        .setProfile(
          sampleProfile.xUsername,
          sampleProfile.discordUsername,
          sampleProfile.telegramUsername,
          sampleProfile.evmMonadAddress,
          sampleProfile.solanaAddress,
        )

      // Update profile
      const updatedProfile = { ...sampleProfile, xUsername: "newusername" }
      await gm
        .connect(addr1)
        .setProfile(
          updatedProfile.xUsername,
          updatedProfile.discordUsername,
          updatedProfile.telegramUsername,
          updatedProfile.evmMonadAddress,
          updatedProfile.solanaAddress,
        )

      const profile = await gm.getProfile(addr1.address)
      expect(profile.xUsername).to.equal("newusername")
    })

    it("Should retrieve profile correctly", async () => {
      await gm
        .connect(addr1)
        .setProfile(
          sampleProfile.xUsername,
          sampleProfile.discordUsername,
          sampleProfile.telegramUsername,
          sampleProfile.evmMonadAddress,
          sampleProfile.solanaAddress,
        )

      const profile = await gm.getProfile(addr1.address)
      expect(profile.xUsername).to.equal(sampleProfile.xUsername)
      expect(profile.discordUsername).to.equal(sampleProfile.discordUsername)
      expect(profile.telegramUsername).to.equal(sampleProfile.telegramUsername)
      expect(profile.evmMonadAddress).to.equal(sampleProfile.evmMonadAddress)
      expect(profile.solanaAddress).to.equal(sampleProfile.solanaAddress)
    })
  })

  describe("View Functions", () => {
    it("Should return correct referral rewards", async () => {
      await gm.connect(addr1).referGM(addr2.address, { value: REFER_GM_FEE })
      expect(await gm.referralRewards(addr2.address)).to.equal(ethers.parseEther("0.25"))
    })

    it("Should return correct next claim time", async () => {
      const currentTime = await time.latest()
      expect(await gm.nextClaimTime(addr1.address)).to.equal(currentTime + CLAIM_COOLDOWN)
    })

    it("Should return correct can claim status", async () => {
      expect(await gm.canClaimNow(addr1.address)).to.be.true

      // After setting up rewards and claiming
      await gm.connect(addr1).referGM(addr2.address, { value: REFER_GM_FEE })
      await ethers.provider.send("evm_increaseTime", [CLAIM_COOLDOWN])
      await gm.connect(addr2).claimRewards()

      expect(await gm.canClaimNow(addr2.address)).to.be.false
    })
  })

  describe("Security", () => {
    it("Should reject direct ETH transfers", async () => {
      await expect(
        addr1.sendTransaction({
          to: await gm.getAddress(),
          value: ethers.parseEther("1"),
        }),
      ).to.be.revertedWith("GM: Direct transfers not allowed. Use gm() or referGM() functions")
    })

    it("Should allow owner emergency withdrawal", async () => {
      // This test would need more complex setup to properly test emergency withdrawal
      // as it needs to account for pending rewards
      expect(await gm.owner()).to.equal(owner.address)
    })
  })
})

// Helper to get latest block timestamp
const time = {
  latest: async () => {
    const block = await ethers.provider.getBlock("latest")
    return block.timestamp
  },
}
