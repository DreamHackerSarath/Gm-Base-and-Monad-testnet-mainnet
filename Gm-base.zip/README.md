# GM Monad Smart Contract

A comprehensive smart contract for daily "Good Morning" interactions with referral rewards and on-chain profile management on the Monad blockchain.

## Features

### 🌅 GM Functions
- **gm()**: Send daily GM with 1 MON fee
- **referGM()**: Send referral GM with 0.5 MON fee (splits payment)
- Automatic fee forwarding to owner wallet

### 💰 Referral System
- 60-day reward claiming cooldown
- Automatic reward accumulation
- Secure reward distribution

### 👤 Profile Management
- On-chain user profiles with social media links
- Support for X, Discord, Telegram usernames
- EVM Monad and Solana address storage
- Profile update events for off-chain indexing

## Quick Start

### Prerequisites
- Node.js v16+
- npm or yarn
- Monad testnet MON tokens

### Installation

\`\`\`bash
# Clone the repository
git clone <repository-url>
cd gm-monad-contracts

# Install dependencies
npm install

# Copy environment file
cp .env.example .env
\`\`\`

### Configuration

Edit `.env` file with your details:
\`\`\`env
PRIVATE_KEY=your_private_key_without_0x_prefix
MONAD_TESTNET_RPC_URL=https://testnet-rpc.monad.xyz
\`\`\`

### Deployment

\`\`\`bash
# Compile contracts
npm run compile

# Run tests
npm run test

# Deploy to Monad Testnet
npm run deploy:testnet
\`\`\`

## Contract Details

### Network Information

### **Official Monad Testnet Details** (from developers.monad.xyz)
- **RPC URL**: https://testnet-rpc.monad.xyz
- **Chain ID**: 41454
- **Explorer**: https://testnet.monadexplorer.com
- **Currency Symbol**: MON
- **Faucet**: https://faucet.monad.xyz
- **Developer Portal**: https://developers.monad.xyz

### **Key Features**
- **Full EVM Compatibility**: Deploy existing Ethereum contracts without changes
- **10,000 TPS**: High-performance blockchain optimized for scale
- **Low Gas Fees**: Efficient execution environment
- **Developer Friendly**: Comprehensive tooling and documentation

### **Getting Started on Monad**

1. **Get Testnet MON**
   \`\`\`bash
   # Visit the official faucet
   https://faucet.monad.xyz
   \`\`\`

2. **Add Monad Testnet to MetaMask**
   - Network Name: Monad Testnet
   - RPC URL: https://testnet-rpc.monad.xyz
   - Chain ID: 41454
   - Currency Symbol: MON
   - Block Explorer: https://testnet.monadexplorer.com

3. **Deploy Your Contract**
   \`\`\`bash
   npm run deploy:testnet
   \`\`\`

### **Monad Resources**
- 📖 **Documentation**: https://developers.monad.xyz
- 💬 **Developer Discord**: https://discord.gg/monad
- 🐦 **Twitter**: https://twitter.com/monad_xyz
- 🌐 **Website**: https://monad.xyz

### Contract Functions

#### Core GM Functions
\`\`\`solidity
function gm() external payable
function referGM(address referrer) external payable
function claimRewards() external
