"use client"

import { createConfig, http } from "wagmi"
import { injected, metaMask, walletConnect } from "wagmi/connectors"
import { baseMainnet } from "./monad-config"

const projectId = process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID || "your-project-id"

export const config = createConfig({
  chains: [baseMainnet],
  connectors: [
    injected(),
    metaMask(),
    walletConnect({
      projectId,
      metadata: {
        name: "GM Base",
        description: "Daily good morning on Base",
        url: "https://gm.base.org",
        icons: ["https://gm.base.org/icon.png"],
      },
    }),
  ],
  transports: {
    [baseMainnet.id]: http(),
  },
})
