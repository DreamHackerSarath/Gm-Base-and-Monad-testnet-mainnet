import { defineChain } from "viem"

// Base Mainnet configuration (https://docs.base.org)
export const baseMainnet = defineChain({
  id: 8453,
  name: "Base",
  network: "base",
  nativeCurrency: {
    decimals: 18,
    name: "Ethereum",
    symbol: "ETH",
  },
  rpcUrls: {
    default: {
      http: ["https://mainnet.base.org"],
    },
    public: {
      http: ["https://mainnet.base.org"],
    },
  },
  blockExplorers: {
    default: {
      name: "BaseScan",
      url: "https://basescan.org",
    },
  },
  testnet: false,
})

// Smart contract addresses (replace with actual deployed addresses)
export const CONTRACT_ADDRESSES = {
  GM_CONTRACT: "0x1234567890123456789012345678901234567890",
} as const

// GM Contract ABI
export const GM_CONTRACT_ABI = [
  {
    inputs: [{ name: "initialOwner", type: "address" }],
    stateMutability: "nonpayable",
    type: "constructor",
  },
  {
    inputs: [],
    name: "gm",
    outputs: [],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [{ name: "referrer", type: "address" }],
    name: "referGM",
    outputs: [],
    stateMutability: "payable",
    type: "function",
  },
  {
    inputs: [],
    name: "claimRewards",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [
      { name: "xUsername", type: "string" },
      { name: "discordUsername", type: "string" },
      { name: "telegramUsername", type: "string" },
      { name: "evmAddress", type: "address" },
      { name: "solanaAddress", type: "string" },
    ],
    name: "setProfile",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function",
  },
  {
    inputs: [{ name: "user", type: "address" }],
    name: "getProfile",
    outputs: [
      {
        components: [
          { name: "xUsername", type: "string" },
          { name: "discordUsername", type: "string" },
          { name: "telegramUsername", type: "string" },
          { name: "evmAddress", type: "address" },
          { name: "solanaAddress", type: "string" },
        ],
        name: "",
        type: "tuple",
      },
    ],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "gmCount",
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [{ name: "referrer", type: "address" }],
    name: "referralRewards",
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [{ name: "claimer", type: "address" }],
    name: "nextClaimTime",
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [{ name: "claimer", type: "address" }],
    name: "canClaimNow",
    outputs: [{ name: "", type: "bool" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [{ name: "", type: "address" }],
    name: "pendingRewards",
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
  {
    inputs: [],
    name: "owner",
    outputs: [{ name: "", type: "address" }],
    stateMutability: "view",
    type: "function",
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, name: "from", type: "address" },
      { indexed: false, name: "timestamp", type: "uint256" },
    ],
    name: "GMSent",
    type: "event",
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, name: "from", type: "address" },
      { indexed: true, name: "referrer", type: "address" },
      { indexed: false, name: "timestamp", type: "uint256" },
    ],
    name: "GMReferred",
    type: "event",
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, name: "claimer", type: "address" },
      { indexed: false, name: "amount", type: "uint256" },
      { indexed: false, name: "timestamp", type: "uint256" },
    ],
    name: "RewardsClaimed",
    type: "event",
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, name: "user", type: "address" },
      { indexed: false, name: "xUsername", type: "string" },
      { indexed: false, name: "discordUsername", type: "string" },
      { indexed: false, name: "telegramUsername", type: "string" },
      { indexed: false, name: "evmAddress", type: "address" },
      { indexed: false, name: "solanaAddress", type: "string" },
    ],
    name: "ProfileUpdated",
    type: "event",
  },
] as const

// Mock token ABI for balance checking
export const MOAND_TOKEN_ABI = [
  {
    inputs: [{ name: "account", type: "address" }],
    name: "balanceOf",
    outputs: [{ name: "", type: "uint256" }],
    stateMutability: "view",
    type: "function",
  },
] as const
