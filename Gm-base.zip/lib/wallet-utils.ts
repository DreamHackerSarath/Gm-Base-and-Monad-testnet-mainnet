"use client"

// Base (Coinbase L2) network configuration
export interface WalletAccount {
  address: string
  isConnected: boolean
}

export interface NetworkInfo {
  chainId: number
  name: string
  rpcUrl: string
  explorerUrl: string
  currencySymbol: string
  faucetUrl?: string
}

// Base Mainnet configuration (https://docs.base.org)
export const baseMainnet: NetworkInfo = {
  chainId: 8453, // Base Mainnet chain ID
  name: "Base",
  rpcUrl: "https://mainnet.base.org", // Official Base RPC URL
  explorerUrl: "https://basescan.org", // Official Base explorer
  currencySymbol: "ETH", // Base uses ETH for gas/fees
}

// Base Sepolia testnet (for reference / dev)
export const baseSepolia: NetworkInfo = {
  chainId: 84532,
  name: "Base Sepolia",
  rpcUrl: "https://sepolia.base.org",
  explorerUrl: "https://sepolia.basescan.org",
  currencySymbol: "ETH",
  faucetUrl: "https://www.coinbase.com/faucets/base-ethereum-sepolia-faucet",
}

// Mock wallet state for development
let mockWallet: WalletAccount = {
  address: "",
  isConnected: false,
}

const mockNetwork = {
  chainId: 1, // Default to Ethereum mainnet
}

export const connectWallet = async (): Promise<WalletAccount> => {
  // In production, this would use actual wallet connection
  return new Promise((resolve) => {
    setTimeout(() => {
      mockWallet = {
        address: "0x1234567890123456789012345678901234567890",
        isConnected: true,
      }
      mockNetwork.chainId = baseMainnet.chainId
      resolve(mockWallet)
    }, 1000)
  })
}

export const disconnectWallet = async (): Promise<void> => {
  mockWallet = {
    address: "",
    isConnected: false,
  }
}

export const getAccount = (): WalletAccount => {
  return mockWallet
}

export const getNetwork = () => {
  return mockNetwork
}

export const switchNetwork = async (chainId: number): Promise<void> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      mockNetwork.chainId = chainId
      resolve()
    }, 500)
  })
}

export const addBaseToWallet = async (): Promise<void> => {
  // In production, this would add the network to MetaMask
  if (typeof window !== "undefined" && window.ethereum) {
    try {
      await window.ethereum.request({
        method: "wallet_addEthereumChain",
        params: [
          {
            chainId: `0x${baseMainnet.chainId.toString(16)}`, // Convert to hex
            chainName: baseMainnet.name,
            nativeCurrency: {
              name: "Ethereum",
              symbol: baseMainnet.currencySymbol,
              decimals: 18,
            },
            rpcUrls: [baseMainnet.rpcUrl],
            blockExplorerUrls: [baseMainnet.explorerUrl],
          },
        ],
      })
    } catch (error) {
      console.error("Failed to add Base to wallet:", error)
    }
  }
}

export const formatAddress = (address: string): string => {
  if (!address) return ""
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

export const getExplorerUrl = (address: string, type: "address" | "tx" = "address"): string => {
  return `${baseMainnet.explorerUrl}/${type}/${address}`
}

// Utility to check if we're on the correct network
export const isCorrectNetwork = (chainId: number): boolean => {
  return chainId === baseMainnet.chainId
}

// Get network display info
export const getNetworkDisplayInfo = (chainId: number): NetworkInfo | null => {
  if (chainId === baseMainnet.chainId) return baseMainnet
  if (chainId === baseSepolia.chainId) return baseSepolia
  return null
}
