"use client"

// Alchemy integration for enhanced Base RPC services
export interface AlchemyConfig {
  apiKey: string
  network: string
  rpcUrl: string
  webhookUrl?: string
}

export interface AlchemyWebhookEvent {
  webhookId: string
  id: string
  createdAt: string
  type: string
  event: {
    network: string
    activity: Array<{
      fromAddress: string
      toAddress: string
      blockNum: string
      hash: string
      value: number
      asset: string
      category: string
      rawContract: {
        address: string
        decimal: string
      }
    }>
  }
}

class AlchemyService {
  private config: AlchemyConfig

  constructor() {
    this.config = {
      apiKey: process.env.NEXT_PUBLIC_ALCHEMY_API_KEY || "",
      network: "base-mainnet",
      rpcUrl: process.env.NEXT_PUBLIC_ALCHEMY_BASE_RPC_URL || "https://mainnet.base.org",
      webhookUrl: process.env.ALCHEMY_WEBHOOK_URL,
    }
  }

  // Enhanced RPC methods with Alchemy's reliability and performance
  async getEnhancedBalance(address: string): Promise<string> {
    try {
      const response = await fetch(this.config.rpcUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          jsonrpc: "2.0",
          method: "eth_getBalance",
          params: [address, "latest"],
          id: 1,
        }),
      })

      const data = await response.json()
      return data.result || "0x0"
    } catch (error) {
      console.error("Failed to get enhanced balance:", error)
      return "0x0"
    }
  }

  async getTransactionHistory(address: string, limit = 10): Promise<any[]> {
    try {
      // Alchemy's enhanced transaction history API
      const response = await fetch(`${this.config.rpcUrl}/v2/${this.config.apiKey}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          jsonrpc: "2.0",
          method: "alchemy_getAssetTransfers",
          params: [
            {
              fromBlock: "0x0",
              toBlock: "latest",
              fromAddress: address,
              category: ["external", "internal", "erc20", "erc721", "erc1155"],
              maxCount: limit,
              order: "desc",
            },
          ],
          id: 1,
        }),
      })

      const data = await response.json()
      return data.result?.transfers || []
    } catch (error) {
      console.error("Failed to get transaction history:", error)
      return []
    }
  }

  async getGasPrice(): Promise<string> {
    try {
      const response = await fetch(this.config.rpcUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          jsonrpc: "2.0",
          method: "eth_gasPrice",
          id: 1,
        }),
      })

      const data = await response.json()
      return data.result || "0x0"
    } catch (error) {
      console.error("Failed to get gas price:", error)
      return "0x0"
    }
  }

  // Webhook management for real-time notifications
  async createWebhook(addresses: string[]): Promise<string> {
    try {
      // Create webhook for monitoring GM contract events
      const response = await fetch(`https://dashboard.alchemy.com/api/create-webhook`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Alchemy-Token": this.config.apiKey,
        },
        body: JSON.stringify({
          network: this.config.network,
          webhook_type: "ADDRESS_ACTIVITY",
          webhook_url: this.config.webhookUrl,
          addresses: addresses,
        }),
      })

      const data = await response.json()
      return data.webhook_id
    } catch (error) {
      console.error("Failed to create webhook:", error)
      throw error
    }
  }

  // Enhanced analytics and monitoring
  async getNetworkStats(): Promise<any> {
    try {
      // Get enhanced network statistics
      const [blockNumber, gasPrice, pendingTxs] = await Promise.all([
        this.getBlockNumber(),
        this.getGasPrice(),
        this.getPendingTransactionCount(),
      ])

      return {
        blockNumber: Number.parseInt(blockNumber, 16),
        gasPrice: Number.parseInt(gasPrice, 16),
        pendingTransactions: pendingTxs,
        timestamp: Date.now(),
      }
    } catch (error) {
      console.error("Failed to get network stats:", error)
      return null
    }
  }

  private async getBlockNumber(): Promise<string> {
    const response = await fetch(this.config.rpcUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        method: "eth_blockNumber",
        id: 1,
      }),
    })
    const data = await response.json()
    return data.result || "0x0"
  }

  private async getPendingTransactionCount(): Promise<number> {
    try {
      const response = await fetch(this.config.rpcUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          jsonrpc: "2.0",
          method: "eth_getBlockTransactionCountByNumber",
          params: ["pending"],
          id: 1,
        }),
      })
      const data = await response.json()
      return Number.parseInt(data.result || "0x0", 16)
    } catch (error) {
      return 0
    }
  }
}

export const alchemyService = new AlchemyService()

// Base network benefits
export const BASE_BENEFITS = {
  ethereumSecurity: {
    title: "Secured by Ethereum",
    description:
      "Base is an Ethereum L2 built on the OP Stack. It inherits Ethereum's security while settling transactions on Ethereum mainnet, giving you the trust of L1 with the speed of an L2.",
  },
  lowFees: {
    title: "Low fees",
    description:
      "Base offers significantly cheaper transactions than Ethereum mainnet, making consumer apps affordable to use while remaining fully EVM compatible.",
  },
  coinbaseEcosystem: {
    title: "Coinbase ecosystem",
    description:
      "Incubated by Coinbase, Base benefits from deep liquidity, easy fiat on-ramps, and a fast-growing ecosystem of developers and users.",
  },
} as const
