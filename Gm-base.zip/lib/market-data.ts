"use client"

// CoinMarketCap API integration for real-time market data
export interface CryptoPrice {
  id: number
  name: string
  symbol: string
  price: number
  percent_change_1h: number
  percent_change_24h: number
  percent_change_7d: number
  market_cap: number
  volume_24h: number
  circulating_supply: number
  last_updated: string
}

export interface MarketMetrics {
  total_market_cap: number
  total_volume_24h: number
  bitcoin_dominance: number
  ethereum_dominance: number
  active_cryptocurrencies: number
  active_exchanges: number
}

export interface FearGreedIndex {
  value: number
  value_classification: string
  timestamp: string
}

class MarketDataService {
  private baseUrl = "https://pro-api.coinmarketcap.com"
  private apiKey = process.env.NEXT_PUBLIC_COINMARKETCAP_API_KEY || ""

  async getTopCryptocurrencies(limit = 10): Promise<CryptoPrice[]> {
    try {
      // In production, this would make actual API calls
      // For demo, returning mock data based on the CoinMarketCap screenshot
      return [
        {
          id: 1,
          name: "Bitcoin",
          symbol: "BTC",
          price: 117314.81,
          percent_change_1h: 0.63,
          percent_change_24h: -2.21,
          percent_change_7d: 7.82,
          market_cap: 2333311298191,
          volume_24h: 96950814285,
          circulating_supply: 19.89,
          last_updated: new Date().toISOString(),
        },
        {
          id: 1027,
          name: "Ethereum",
          symbol: "ETH",
          price: 3076.02,
          percent_change_1h: 0.92,
          percent_change_24h: 2.18,
          percent_change_7d: 17.92,
          market_cap: 369918976373,
          volume_24h: 37234691873,
          circulating_supply: 120.71,
          last_updated: new Date().toISOString(),
        },
        {
          id: 52,
          name: "XRP",
          symbol: "XRP",
          price: 2.89,
          percent_change_1h: 0.59,
          percent_change_24h: -1.32,
          percent_change_7d: 25.6,
          market_cap: 171137871707,
          volume_24h: 8841669250,
          circulating_supply: 59.13,
          last_updated: new Date().toISOString(),
        },
        {
          id: 825,
          name: "Tether",
          symbol: "USDT",
          price: 1.0,
          percent_change_1h: 0.01,
          percent_change_24h: 0.0,
          percent_change_7d: -0.02,
          market_cap: 159898521661,
          volume_24h: 143549008904,
          circulating_supply: 159.88,
          last_updated: new Date().toISOString(),
        },
        {
          id: 1839,
          name: "BNB",
          symbol: "BNB",
          price: 687.51,
          percent_change_1h: 0.32,
          percent_change_24h: -0.59,
          percent_change_7d: 4.38,
          market_cap: 95763696094,
          volume_24h: 2137652226,
          circulating_supply: 139.28,
          last_updated: new Date().toISOString(),
        },
      ]
    } catch (error) {
      console.error("Failed to fetch cryptocurrency data:", error)
      return []
    }
  }

  async getGlobalMetrics(): Promise<MarketMetrics> {
    try {
      // Mock data based on CoinMarketCap screenshot
      return {
        total_market_cap: 3690000000000, // $3.69T
        total_volume_24h: 204558000000, // $204.55B
        bitcoin_dominance: 63.1,
        ethereum_dominance: 10.0,
        active_cryptocurrencies: 18520,
        active_exchanges: 833,
      }
    } catch (error) {
      console.error("Failed to fetch global metrics:", error)
      throw error
    }
  }

  async getFearGreedIndex(): Promise<FearGreedIndex> {
    try {
      // Mock data - Fear & Greed Index showing 70 (Greed)
      return {
        value: 70,
        value_classification: "Greed",
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error("Failed to fetch Fear & Greed Index:", error)
      throw error
    }
  }

  async getMonadPrice(): Promise<number> {
    try {
      // Mock Monad price - would be fetched from CMC when listed
      return 0.0 // Monad not yet listed on CMC
    } catch (error) {
      console.error("Failed to fetch Monad price:", error)
      return 0.0
    }
  }

  formatPrice(price: number): string {
    if (price >= 1000) {
      return `$${price.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
    } else if (price >= 1) {
      return `$${price.toFixed(4)}`
    } else {
      return `$${price.toFixed(8)}`
    }
  }

  formatMarketCap(marketCap: number): string {
    if (marketCap >= 1e12) {
      return `$${(marketCap / 1e12).toFixed(2)}T`
    } else if (marketCap >= 1e9) {
      return `$${(marketCap / 1e9).toFixed(2)}B`
    } else if (marketCap >= 1e6) {
      return `$${(marketCap / 1e6).toFixed(2)}M`
    } else {
      return `$${marketCap.toLocaleString()}`
    }
  }

  formatPercentChange(change: number): { value: string; color: string } {
    const color = change >= 0 ? "text-green-500" : "text-red-500"
    const sign = change >= 0 ? "+" : ""
    return {
      value: `${sign}${change.toFixed(2)}%`,
      color,
    }
  }
}

export const marketDataService = new MarketDataService()
